# Private Two-Person Chat

Version 0.2.0 adds the complete core PostgreSQL schema and repeatable migration/seed tooling.

## Requirements

- Node.js 20, 22, or 24
- npm
- PostgreSQL 14 or newer, or a Supabase PostgreSQL project

## Setup

```bash
npm install
```

PowerShell:

```powershell
Copy-Item .env.example .env
```

Linux/macOS:

```bash
cp .env.example .env
```

Edit `.env` and set `DATABASE_URL`. For Supabase, use its pooled PostgreSQL connection string and set `DATABASE_SSL=true`.

```bash
npm run db:migrate
npm run db:seed
npm test
npm run dev
```

Open `http://localhost:3000/health`. With a healthy configured database, it should report:

```json
{"status":"ok","database":{"configured":true,"reachable":true}}
```

## Database Commands

```bash
npm run db:migrate
npm run db:status
npm run db:seed
npm run db:setup
```

Development-only destructive reset:

```bash
npm run db:reset:dev
```

The reset command refuses to run when `NODE_ENV=production` and requires typing `RESET`.

## Schema

- `participants`: exactly two predefined identities after seeding
- `sessions`: hashed opaque session tokens and expiration/revocation data
- `messages`: text, replies, timestamps, delivery timestamp, and idempotency key
- `participant_state`: one read marker per participant
- `schema_migrations`: migration filenames and SHA-256 checksums

## Migration Safety

Applied migrations must never be edited. The runner compares each applied file's SHA-256 checksum and stops if history was changed. Add a new numbered migration instead.

## Current Limitation

Identity verification and session APIs are intentionally deferred to Stage 3. Do not yet expose this version publicly as an authenticated chat.
