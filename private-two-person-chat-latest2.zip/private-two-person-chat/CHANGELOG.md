# Changelog

## 0.2.0 - 2026-09-23
- Added checksum-based migration runner and status command
- Added PostgreSQL participants, sessions, messages, and participant-state tables
- Added foreign keys, checks, indexes, and updated-at triggers
- Added idempotent seed for exactly Tushar and Friend
- Added safe development-only reset script
- Added database query timeout configuration
- Added schema structure tests and database setup documentation

## 0.1.0 - 2026-09-23
- Added project foundation, Express, Socket.IO, security headers, health checks, and tracking docs
