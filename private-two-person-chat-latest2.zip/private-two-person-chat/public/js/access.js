// Secure access and session handling are introduced in Stage 3 and Stage 4.
