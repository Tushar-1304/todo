# Stage 2 Manual Test Checklist

- [ ] `npm install` completes
- [ ] `.env` contains a valid `DATABASE_URL`
- [ ] `npm run check` passes
- [ ] `npm test` passes
- [ ] `npm run db:migrate` applies three migrations
- [ ] Re-running `npm run db:migrate` skips all migrations
- [ ] `npm run db:status` shows all migrations as applied
- [ ] `npm run db:seed` verifies exactly two participants
- [ ] Database contains `tushar` and `friend`
- [ ] Database contains two participant-state rows
- [ ] `npm run dev` starts successfully
- [ ] `/health` reports the database as configured and reachable
