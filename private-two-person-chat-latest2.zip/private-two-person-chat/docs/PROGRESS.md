# Project Progress

## Stage 0: Specification and Tracking
- [x] Complete

## Stage 1: Foundation
- [x] Express and shared Socket.IO HTTP server
- [x] Static pages and health endpoint
- [x] Environment validation, security headers, errors, shutdown
- [x] PostgreSQL pool foundation
- [ ] Owner manual verification

## Stage 2: Database
- [x] Checksum-based migration runner
- [x] Migration status command
- [x] Participants table
- [x] Sessions table
- [x] Messages table
- [x] Participant state table
- [x] Constraints and indexes
- [x] Exactly two participant seeds
- [x] Safe development reset command
- [x] SQL structure tests
- [ ] Owner database verification

## Stage 3: Secure Identity and Sessions
- [ ] Access hash generator
- [ ] Verification endpoint
- [ ] Opaque session creation and authentication
- [ ] Logout and rate limiting
