# Private Two-Person Chat

Version 0.3.0 adds secure access-code verification and revocable, server-managed browser sessions.

## Setup

```bash
npm install
```

Copy `.env.example` to `.env`, configure PostgreSQL, and run:

```bash
npm run db:setup
```

Generate a different Argon2id hash for each participant:

```bash
npm run access:hash
npm run access:hash
```

Put the first hash in `TUSHAR_ACCESS_CODE_HASH` and the second in `FRIEND_ACCESS_CODE_HASH`. Create a random pepper of at least 32 characters for `SESSION_TOKEN_PEPPER`. Never commit `.env` or store readable codes in source files.

Run:

```bash
npm test
npm run check
npm run dev
```

## Authentication API

- `POST /api/access/verify` with JSON `{ "identity": "tushar", "accessCode": "..." }`
- `GET /api/session` restores and returns an authenticated session
- `POST /api/session/logout` revokes the current browser session

The raw opaque token exists only in an HTTP-only cookie. PostgreSQL stores only its HMAC-SHA-256 hash. Access-code hashes use Argon2id.

## Maintenance

Revoke every currently active device session:

```bash
npm run sessions:revoke
```

## Current Limitation

The API is complete, but the browser identity form arrives in Stage 4. Stage 3 can be tested with an API client or browser developer console.
