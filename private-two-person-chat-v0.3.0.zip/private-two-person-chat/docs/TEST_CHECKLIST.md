# Stage 3 Manual Test Checklist

- [ ] Install dependencies with `npm install`
- [ ] Apply migration 004 with `npm run db:migrate`
- [ ] Generate two separate hashes with `npm run access:hash`
- [ ] Add both hashes and a 32+ character pepper to `.env`
- [ ] Start with `npm run dev`
- [ ] Correct Tushar code returns HTTP 201 from `POST /api/access/verify`
- [ ] Correct Friend code returns HTTP 201
- [ ] Incorrect code returns HTTP 401 with a generic message
- [ ] Repeated failed verification returns HTTP 429
- [ ] Successful verification sets an HTTP-only cookie
- [ ] `GET /api/session` returns the authenticated identity
- [ ] `POST /api/session/logout` returns HTTP 204
- [ ] The revoked cookie no longer authenticates
- [ ] `npm run sessions:revoke` invalidates all active devices after confirmation
