# Project Progress

## Stages 0-2
- [x] Requirements, foundation, PostgreSQL schema, migrations, and two participant seeds

## Stage 3: Secure Identity and Sessions
- [x] Argon2id access-code verification
- [x] Cryptographically random opaque session tokens
- [x] HMAC-SHA-256 token hashing with server pepper
- [x] HTTP-only same-origin cookies
- [x] Session restoration and current-session API
- [x] Current-device logout and database revocation
- [x] Global maintenance session revocation script
- [x] Route and identity-specific rate limiting
- [x] Request validation and generic access errors
- [x] Authentication middleware
- [x] Access-code hash generator
- [x] Participant identity database constraint
- [ ] Owner integration verification

## Stage 4: Identity Frontend
- [ ] Identity selection and access-code form
- [ ] Session restoration and redirects
- [ ] Responsive validation and loading UI
