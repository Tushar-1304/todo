# Changelog

## 0.3.0 - 2026-09-23
- Added Argon2id private access-code verification
- Added opaque HMAC-hashed database sessions and HTTP-only cookies
- Added session restoration, authentication middleware, and logout
- Added access and session rate limiting
- Added body validation and generic access errors
- Added access-code hash generator and all-session revocation utility
- Restricted participant identities to Tushar and Friend

## 0.2.0 - 2026-09-23
- Added checksum migrations, core PostgreSQL schema, indexes, seeds, and reset tooling

## 0.1.0 - 2026-09-23
- Added application foundation, Express, Socket.IO, security headers, and tracking docs
