# Stage 7 End-to-End Manual Test Checklist

- [ ] Complete environment setup and run `npm run db:migrate`
- [ ] Run `npm test` and `npm run check`
- [ ] Open Tushar in a normal browser and Friend in a private browser
- [ ] Both chat pages show the other participant's name
- [ ] Both pages show Online once connected
- [ ] Send a message in each direction without refreshing
- [ ] Sending changes to Sent, then Delivered, then Read
- [ ] Press Enter to send and Shift+Enter for a new line
- [ ] Reply to an older message and verify its preview
- [ ] Click a reply preview and verify the original message is located
- [ ] Refresh either browser and verify history persists
- [ ] Close one of two same-user tabs and verify presence remains Online
- [ ] Disconnect network briefly and verify Reconnecting then synchronization
- [ ] Scroll upward and verify older history loads without jumping
- [ ] Receive a message while reading older history and verify the New messages button
- [ ] Logout and verify the browser returns to the access page
- [ ] Test at approximately 375px mobile width without horizontal overflow
