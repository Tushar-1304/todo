import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";

test("server uses authenticated socket configuration", async () => {
  const server = await fs.readFile("server.js", "utf8");
  const sockets = await fs.readFile("src/sockets/index.js", "utf8");
  assert.match(server, /configureSockets\(io\)/);
  assert.match(sockets, /io\.use\(authenticateSocket\)/);
});
test("client and server event names remain aligned", async () => {
  const client = await fs.readFile("public/js/socket.js", "utf8");
  const server = await fs.readFile("src/sockets/chat.handlers.js", "utf8");
  for (const event of ["message:send", "message:delivered", "messages:read", "chat:sync"]) {
    assert.ok(client.includes(event), `client missing ${event}`);
    assert.ok(server.includes(event), `server missing ${event}`);
  }
});
