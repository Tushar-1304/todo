import test from "node:test";
import assert from "node:assert/strict";
import { addParticipantSocket, isParticipantOnline, removeParticipantSocket, resetPresenceStore } from "../src/sockets/presence.store.js";

test("participant remains online until every socket disconnects", () => {
  resetPresenceStore();
  assert.equal(addParticipantSocket("u1", "s1").changed, true);
  assert.equal(addParticipantSocket("u1", "s2").changed, false);
  assert.equal(removeParticipantSocket("u1", "s1").online, true);
  assert.equal(isParticipantOnline("u1"), true);
  const last = removeParticipantSocket("u1", "s2");
  assert.equal(last.online, false);
  assert.equal(last.changed, true);
});
