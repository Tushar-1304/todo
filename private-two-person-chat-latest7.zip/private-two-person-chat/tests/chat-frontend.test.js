import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
test("chat page includes required interactive controls",async()=>{const html=await fs.readFile("public/chat.html","utf8");for(const id of ["message-region","message-list","message-input","send-button","reply-bar","load-older-button","logout-button"])assert.ok(html.includes(`id="${id}"`),id);});
test("chat rendering uses textContent and never innerHTML",async()=>{for(const file of ["public/js/ui.js","public/js/chat.js"]){const js=await fs.readFile(file,"utf8");assert.ok(!js.includes("innerHTML"),file);}assert.ok((await fs.readFile("public/js/ui.js","utf8")).includes("textContent"));});
test("chat client handles delivery, read, sync, replies, and logout",async()=>{const js=await fs.readFile("public/js/chat.js","utf8");for(const token of ["confirmDelivered","markRead","sync(","setReply","logout()"])assert.ok(js.includes(token),token);});
