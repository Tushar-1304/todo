# Private Two-Person Chat

Version 0.7.0 is a complete usable MVP interface for the private conversation. It connects secure identity sessions, PostgreSQL history, and authenticated Socket.IO communication.

## Run

```bash
npm install
npm run db:migrate
npm run db:seed
npm test
npm run check
npm run dev
```

Open `http://localhost:3000` in a normal window for one participant and a private window for the other.

## User Experience

- The access page verifies Tushar or Friend and remembers the browser securely.
- `/chat` restores the session, loads the newest 30 messages, and connects Socket.IO.
- Messages render optimistically as Sending and reconcile with the PostgreSQL record after acknowledgement.
- Incoming messages are acknowledged as Delivered and visible messages advance the read marker.
- Replies preserve a safe preview of the original message.
- Scrolling near the top loads older history while preserving position.
- Reconnection synchronizes messages newer than the newest local message.
- Multiple tabs and devices are counted before a participant becomes Offline.

## Message Status

- **Sending:** waiting for server acknowledgement
- **Sent:** stored in PostgreSQL
- **Delivered:** received and acknowledged by the other participant's browser
- **Read:** the other participant's read marker reached the message
- **Failed:** the socket operation failed or timed out

## Frontend Safety

Message and reply content are rendered through `textContent`. The interface does not use `innerHTML` for untrusted content. All API and Socket.IO connections use the same origin.

## Next Stage

Stage 8 performs the final security audit, automated integration coverage, provider-independent deployment documentation, and v1.0.0 release packaging.
