# Changelog

## 0.7.0 - 2026-09-23
- Added complete responsive private chat interface
- Added safe message bubbles, date separators, timestamps, and status indicators
- Added optimistic sending and server reconciliation
- Added reply selection, preview, cancellation, and original-message navigation
- Added history loading, scroll preservation, and new-message prompts
- Added live presence, connection states, delivery/read handling, and reconnect synchronization
- Added keyboard composer behavior, logout, and frontend tests

## 0.6.0 - 2026-09-23
- Added authenticated Socket.IO communication, delivery/read events, presence, and recovery
## 0.5.0 - 2026-09-23
- Added message persistence, pagination, replies, read markers, and recovery APIs
## 0.4.0 - 2026-09-23
- Added identity frontend and session restoration
## 0.3.0 - 2026-09-23
- Added secure access-code authentication and opaque sessions
## 0.2.0 - 2026-09-23
- Added PostgreSQL schema and migrations
## 0.1.0 - 2026-09-23
- Added application foundation
