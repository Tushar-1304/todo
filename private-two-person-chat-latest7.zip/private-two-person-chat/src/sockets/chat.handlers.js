import { z } from "zod";
import { createMessageSchema, readMessageSchema } from "../validators/message.validators.js";
import { confirmMessageDelivered, createTextMessage, markMessagesRead, syncMessages } from "../services/message.service.js";
import { consumeMessageAllowance } from "./socket-rate-limit.js";
import { isParticipantOnline } from "./presence.store.js";

const deliverySchema = z.object({ messageId: z.string().uuid() }).strict();
const syncSchema = z.object({ after: z.string().uuid().optional(), limit: z.number().int().min(1).max(200).optional() }).strict();

function safeAck(ack, payload) { if (typeof ack === "function") ack(payload); }
function failure(error) {
  return { ok: false, error: { code: error.code || "CHAT_ERROR", message: error.statusCode && error.statusCode < 500 ? error.message : "The operation could not be completed." } };
}

export function registerChatHandlers(io, socket) {
  const participant = socket.data.auth.participant;
  const otherParticipant = socket.data.auth.otherParticipant;
  const otherRoom = otherParticipant ? `participant:${otherParticipant.id}` : null;

  socket.on("message:send", async (payload, ack) => {
    if (!consumeMessageAllowance(participant.id)) return safeAck(ack, { ok: false, error: { code: "MESSAGE_RATE_LIMITED", message: "You are sending messages too quickly." } });
    const parsed = createMessageSchema.safeParse(payload);
    if (!parsed.success) return safeAck(ack, { ok: false, error: { code: "VALIDATION_ERROR", message: "The message is invalid." } });
    try {
      const result = await createTextMessage(participant.id, parsed.data);
      safeAck(ack, { ok: true, data: result });
      if (!result.duplicate && otherRoom) io.to(otherRoom).emit("message:new", { message: result.message });
    } catch (error) { safeAck(ack, failure(error)); }
  });

  socket.on("message:delivered", async (payload, ack) => {
    const parsed = deliverySchema.safeParse(payload);
    if (!parsed.success) return safeAck(ack, { ok: false, error: { code: "VALIDATION_ERROR", message: "Invalid delivery acknowledgement." } });
    try {
      const data = await confirmMessageDelivered(parsed.data.messageId, participant.id);
      if (otherRoom) io.to(otherRoom).emit("message:delivered", data);
      safeAck(ack, { ok: true, data });
    } catch (error) { safeAck(ack, failure(error)); }
  });

  socket.on("messages:read", async (payload, ack) => {
    const parsed = readMessageSchema.safeParse(payload);
    if (!parsed.success) return safeAck(ack, { ok: false, error: { code: "VALIDATION_ERROR", message: "Invalid read marker." } });
    try {
      const data = await markMessagesRead(participant.id, parsed.data.messageId);
      if (otherRoom) io.to(otherRoom).emit("messages:read", { participantId: participant.id, ...data });
      safeAck(ack, { ok: true, data });
    } catch (error) { safeAck(ack, failure(error)); }
  });

  socket.on("chat:sync", async (payload = {}, ack) => {
    const parsed = syncSchema.safeParse(payload);
    if (!parsed.success) return safeAck(ack, { ok: false, error: { code: "VALIDATION_ERROR", message: "Invalid synchronization request." } });
    try {
      const data = await syncMessages(participant.id, parsed.data);
      safeAck(ack, { ok: true, data, presence: { participantId: otherParticipant?.id || null, online: otherParticipant ? isParticipantOnline(otherParticipant.id) : false } });
    } catch (error) { safeAck(ack, failure(error)); }
  });
}
