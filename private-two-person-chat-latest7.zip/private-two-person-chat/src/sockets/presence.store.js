const socketsByParticipant = new Map();

export function addParticipantSocket(participantId, socketId) {
  const sockets = socketsByParticipant.get(participantId) || new Set();
  const wasOffline = sockets.size === 0;
  sockets.add(socketId);
  socketsByParticipant.set(participantId, sockets);
  return { online: true, changed: wasOffline, connectionCount: sockets.size };
}

export function removeParticipantSocket(participantId, socketId) {
  const sockets = socketsByParticipant.get(participantId);
  if (!sockets) return { online: false, changed: false, connectionCount: 0 };
  sockets.delete(socketId);
  if (sockets.size === 0) {
    socketsByParticipant.delete(participantId);
    return { online: false, changed: true, connectionCount: 0 };
  }
  return { online: true, changed: false, connectionCount: sockets.size };
}

export function isParticipantOnline(participantId) {
  return (socketsByParticipant.get(participantId)?.size || 0) > 0;
}

export function resetPresenceStore() {
  socketsByParticipant.clear();
}
