import { env } from "../config/env.js";
import { authenticateRawToken } from "../services/session.service.js";
import { parseCookieHeader } from "./cookie-parser.js";

export async function authenticateSocket(socket, next) {
  try {
    const cookies = parseCookieHeader(socket.handshake.headers.cookie);
    const auth = await authenticateRawToken(cookies[env.SESSION_COOKIE_NAME]);
    if (!auth) {
      const error = new Error("Authentication required.");
      error.data = { code: "UNAUTHENTICATED" };
      return next(error);
    }
    socket.data.auth = auth;
    return next();
  } catch {
    const error = new Error("Authentication failed.");
    error.data = { code: "AUTHENTICATION_FAILED" };
    return next(error);
  }
}
