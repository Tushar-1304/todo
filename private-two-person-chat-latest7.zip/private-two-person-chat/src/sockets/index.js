import { authenticateSocket } from "./socket-auth.js";
import { addParticipantSocket, isParticipantOnline, removeParticipantSocket } from "./presence.store.js";
import { registerChatHandlers } from "./chat.handlers.js";
import { logger } from "../utils/logger.js";

export function configureSockets(io) {
  io.use(authenticateSocket);
  io.on("connection", (socket) => {
    const participant = socket.data.auth.participant;
    const other = socket.data.auth.otherParticipant;
    const room = `participant:${participant.id}`;
    socket.join(room);
    const presence = addParticipantSocket(participant.id, socket.id);

    if (presence.changed && other) io.to(`participant:${other.id}`).emit("presence:changed", { participantId: participant.id, online: true });
    socket.emit("system:ready", {
      version: "0.6.0",
      participant,
      otherParticipant: other,
      otherParticipantOnline: other ? isParticipantOnline(other.id) : false
    });

    registerChatHandlers(io, socket);
    logger.info("socket_connected", { participantId: participant.id, socketId: socket.id });

    socket.on("disconnect", (reason) => {
      const update = removeParticipantSocket(participant.id, socket.id);
      if (update.changed && other) io.to(`participant:${other.id}`).emit("presence:changed", { participantId: participant.id, online: false });
      logger.info("socket_disconnected", { participantId: participant.id, socketId: socket.id, reason });
    });
  });
}
