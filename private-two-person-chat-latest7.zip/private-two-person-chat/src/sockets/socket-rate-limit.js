import { env } from "../config/env.js";
const buckets = new Map();
export function consumeMessageAllowance(participantId, now = Date.now()) {
  const current = buckets.get(participantId);
  if (!current || now - current.startedAt >= env.SOCKET_MESSAGE_WINDOW_MS) {
    buckets.set(participantId, { startedAt: now, count: 1 });
    return true;
  }
  if (current.count >= env.SOCKET_MESSAGE_MAX) return false;
  current.count += 1;
  return true;
}
export function clearMessageAllowance(participantId) { buckets.delete(participantId); }
