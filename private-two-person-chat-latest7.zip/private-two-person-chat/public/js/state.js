(function () {
  const state = {
    session: null,
    messages: [],
    messageIds: new Set(),
    hasOlder: false,
    replyTo: null,
    otherOnline: false,
    connection: "connecting",
    otherLastReadMessageId: null
  };
  function mergeMessages(messages) {
    let added = 0;
    for (const message of messages) {
      const existing = state.messages.find((item) => item.id === message.id || (item.clientMessageId && item.clientMessageId === message.clientMessageId));
      if (existing) Object.assign(existing, message, { pending: false, failed: false });
      else { state.messages.push(message); state.messageIds.add(message.id); added += 1; }
    }
    state.messages.sort((a,b) => new Date(a.createdAt) - new Date(b.createdAt) || String(a.id).localeCompare(String(b.id)));
    return added;
  }
  function addPending(message) { state.messages.push(message); }
  function removePending(clientMessageId) { state.messages = state.messages.filter((m) => !(m.clientMessageId === clientMessageId && m.pending)); }
  function newestMessage() { return state.messages.filter((m) => m.id).at(-1) || null; }
  function oldestMessage() { return state.messages.find((m) => m.id) || null; }
  window.privateChatState = { state, mergeMessages, addPending, removePending, newestMessage, oldestMessage };
})();
