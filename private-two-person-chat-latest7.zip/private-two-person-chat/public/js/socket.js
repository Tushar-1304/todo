(function () {
  let socket;
  const listeners = new Map();

  function notify(event, payload) {
    for (const listener of listeners.get(event) || []) listener(payload);
  }

  function connect() {
    if (socket) return socket;
    socket = window.io({ transports: ["websocket", "polling"], reconnection: true, reconnectionDelay: 500, reconnectionDelayMax: 5000 });
    socket.on("connect", () => notify("connection", { state: "connected" }));
    socket.on("disconnect", (reason) => notify("connection", { state: "reconnecting", reason }));
    socket.on("connect_error", (error) => {
      notify("connection", { state: error?.data?.code === "UNAUTHENTICATED" ? "unauthenticated" : "reconnecting", error });
      if (error?.data?.code === "UNAUTHENTICATED") socket.disconnect();
    });
    for (const event of ["system:ready", "message:new", "message:delivered", "messages:read", "presence:changed"]) socket.on(event, (payload) => notify(event, payload));
    return socket;
  }

  function emitWithAck(event, payload, timeout = 10000) {
    const active = connect();
    return new Promise((resolve, reject) => {
      active.timeout(timeout).emit(event, payload, (error, response) => {
        if (error) return reject({ code: "ACK_TIMEOUT", message: "The server did not respond in time." });
        if (!response?.ok) return reject(response?.error || { code: "SOCKET_ERROR", message: "The operation failed." });
        resolve(response);
      });
    });
  }

  window.privateChatSocket = Object.freeze({
    connect,
    disconnect: () => { socket?.disconnect(); socket = undefined; },
    on(event, listener) { const set = listeners.get(event) || new Set(); set.add(listener); listeners.set(event, set); return () => set.delete(listener); },
    sendMessage: (payload) => emitWithAck("message:send", payload),
    confirmDelivered: (messageId) => emitWithAck("message:delivered", { messageId }),
    markRead: (messageId) => emitWithAck("messages:read", { messageId }),
    sync: (after) => emitWithAck("chat:sync", after ? { after } : {})
  });
})();
