(function () {
  const elements = Object.fromEntries(["chat-app","contact-avatar","contact-name","presence-dot","presence-label","connection-pill","logout-button","message-region","load-older-button","history-loading","empty-state","message-list","new-messages-button","reply-bar","reply-author","reply-text","cancel-reply-button","composer-form","message-input","character-count","send-button","toast-region"].map((id) => [id.replace(/-([a-z])/g,(_,c)=>c.toUpperCase()),document.getElementById(id)]));
  const { state } = window.privateChatState;

  function formatTime(value) { return new Intl.DateTimeFormat(undefined,{hour:"numeric",minute:"2-digit"}).format(new Date(value)); }
  function dayLabel(value) { const d=new Date(value),today=new Date(),yesterday=new Date();yesterday.setDate(today.getDate()-1);const key=(x)=>`${x.getFullYear()}-${x.getMonth()}-${x.getDate()}`;if(key(d)===key(today))return"Today";if(key(d)===key(yesterday))return"Yesterday";return new Intl.DateTimeFormat(undefined,{dateStyle:"medium"}).format(d); }
  function truncate(text,max=90){return text.length>max?`${text.slice(0,max-1)}…`:text;}
  function statusFor(message) { if(message.failed)return"Failed";if(message.pending)return"Sending";if(state.otherLastReadMessageId){const read=state.messages.find(m=>m.id===state.otherLastReadMessageId);if(read&&new Date(message.createdAt)<=new Date(read.createdAt))return"Read";}if(message.deliveredAt)return"Delivered";return"Sent"; }
  function isNearBottom(){const e=elements.messageRegion;return e.scrollHeight-e.scrollTop-e.clientHeight<110;}
  function scrollBottom(behavior="auto"){elements.messageRegion.scrollTo({top:elements.messageRegion.scrollHeight,behavior});elements.newMessagesButton.hidden=true;}

  function createMessageNode(message, previous) {
    const fragment=document.createDocumentFragment();
    if(!previous||dayLabel(previous.createdAt)!==dayLabel(message.createdAt)){const date=document.createElement("div");date.className="date-separator";date.textContent=dayLabel(message.createdAt);fragment.append(date);}
    const outgoing=message.sender.id===state.session.participant.id;
    const row=document.createElement("article");row.className=`message-row ${outgoing?"outgoing":"incoming"}${message.failed?" failed":""}`;row.dataset.messageId=message.id||"";row.dataset.clientMessageId=message.clientMessageId||"";
    const bubble=document.createElement("div");bubble.className="message-bubble";
    if(message.replyTo){const reply=document.createElement("button");reply.type="button";reply.className="reply-preview";reply.dataset.jumpTo=message.replyTo.id;const author=document.createElement("strong");author.textContent=message.replyTo.senderDisplayName||"Message";const text=document.createElement("span");text.textContent=truncate(message.replyTo.text||"");reply.append(author,text);bubble.append(reply);}
    const p=document.createElement("p");p.className="message-text";p.textContent=message.text;bubble.append(p);
    const meta=document.createElement("div");meta.className="message-meta";const time=document.createElement("time");time.dateTime=message.createdAt;time.textContent=formatTime(message.createdAt);meta.append(time);
    if(outgoing){const status=document.createElement("span");const value=statusFor(message);status.className=`message-status ${value==="Read"?"read":""}`;status.textContent=value;meta.append(status);}
    bubble.append(meta);
    if(message.id&&!message.pending){const actions=document.createElement("div");actions.className="message-actions";const reply=document.createElement("button");reply.type="button";reply.className="reply-button";reply.dataset.replyId=message.id;reply.textContent="Reply";actions.append(reply);bubble.append(actions);}
    row.append(bubble);fragment.append(row);return fragment;
  }

  function renderMessages({ preserveScroll=false, forceBottom=false }={}) {
    const oldHeight=elements.messageRegion.scrollHeight,oldTop=elements.messageRegion.scrollTop,nearBottom=isNearBottom();
    elements.messageList.replaceChildren();state.messages.forEach((m,i)=>elements.messageList.append(createMessageNode(m,state.messages[i-1])));
    elements.emptyState.hidden=state.messages.length>0;elements.loadOlderButton.hidden=!state.hasOlder;elements.historyLoading.hidden=true;
    if(preserveScroll)elements.messageRegion.scrollTop=elements.messageRegion.scrollHeight-oldHeight+oldTop;
    else if(forceBottom||nearBottom)scrollBottom(forceBottom?"auto":"smooth");
  }
  function setSession(session){state.session=session;const other=session.otherParticipant;elements.contactName.textContent=other?.displayName||"Private chat";elements.contactAvatar.textContent=(other?.displayName||"?").charAt(0).toUpperCase();elements.chatApp.setAttribute("aria-busy","false");}
  function setPresence(online){state.otherOnline=online;elements.presenceDot.classList.toggle("online",online);elements.presenceLabel.textContent=online?"Online":"Offline";}
  function setConnection(value){state.connection=value;elements.connectionPill.dataset.state=value;const labels={connected:"Connected",connecting:"Connecting",reconnecting:"Reconnecting",offline:"Offline"};elements.connectionPill.textContent=labels[value]||value;elements.messageInput.disabled=value!=="connected";updateComposer();}
  function updateComposer(){const length=elements.messageInput.value.length;elements.characterCount.textContent=`${length}/2000`;elements.sendButton.disabled=state.connection!=="connected"||!elements.messageInput.value.trim();elements.messageInput.style.height="auto";elements.messageInput.style.height=`${Math.min(elements.messageInput.scrollHeight,132)}px`;}
  function setReply(message){state.replyTo=message;elements.replyBar.hidden=!message;if(message){elements.replyAuthor.textContent=`Replying to ${message.sender.displayName}`;elements.replyText.textContent=truncate(message.text,130);elements.messageInput.focus();}}
  function toast(text,type="error"){const node=document.createElement("div");node.className=`toast ${type}`;node.textContent=text;elements.toastRegion.append(node);setTimeout(()=>node.remove(),4500);}
  function flashMessage(id){const node=elements.messageList.querySelector(`[data-message-id="${CSS.escape(id)}"]`);if(node){node.scrollIntoView({behavior:"smooth",block:"center"});node.animate([{opacity:.35},{opacity:1}],{duration:650});}}
  window.privateChatUi={elements,renderMessages,setSession,setPresence,setConnection,updateComposer,setReply,toast,scrollBottom,isNearBottom,flashMessage,statusFor};
})();
