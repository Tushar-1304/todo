# Changelog

## 0.6.0 - 2026-09-23
- Added authenticated Socket.IO handshakes using the HTTP-only session cookie
- Added participant rooms, real-time message delivery, and sender acknowledgements
- Added persisted delivered timestamps and live read-marker events
- Added multi-tab and multi-device presence tracking
- Added socket message rate limiting and reconnect synchronization
- Added same-origin browser socket client and event consistency tests

## 0.5.0 - 2026-09-23
- Added message persistence, pagination, replies, read markers, unread counts, and recovery APIs

## 0.4.0 - 2026-09-23
- Added identity frontend and session restoration

## 0.3.0 - 2026-09-23
- Added secure access-code authentication and opaque sessions

## 0.2.0 - 2026-09-23
- Added PostgreSQL schema and migrations

## 0.1.0 - 2026-09-23
- Added application foundation
