# Stage 6 Manual Test Checklist

- [ ] Run `npm install`, `npm run db:migrate`, `npm test`, and `npm run check`
- [ ] Authenticate Tushar in a normal browser and Friend in a private browser
- [ ] Both authenticated Socket.IO handshakes connect
- [ ] An unauthenticated browser receives `UNAUTHENTICATED` and cannot connect
- [ ] Tushar sending `message:send` persists the row before Friend receives `message:new`
- [ ] Reusing the same client message UUID does not rebroadcast or duplicate the message
- [ ] Friend acknowledging `message:delivered` updates `delivered_at`
- [ ] Tushar receives the corresponding `message:delivered` event
- [ ] Advancing a read marker emits `messages:read` to the other participant
- [ ] Opening two tabs keeps a participant online after only one tab closes
- [ ] Closing the final tab broadcasts offline
- [ ] Disconnecting and reconnecting with `chat:sync` returns missed messages
- [ ] Exceeding the socket message limit returns `MESSAGE_RATE_LIMITED`
