# Private Two-Person Chat

Version 0.6.0 adds authenticated real-time communication, live presence, delivery acknowledgements, read events, and Socket.IO recovery synchronization.

## Upgrade and Run

```bash
npm install
npm run db:migrate
npm run db:seed
npm test
npm run check
npm run dev
```

The Socket.IO server and Express use the same HTTP server and public origin. Authentication comes from the existing HTTP-only session cookie during the socket handshake.

## Socket Events

Client to server:

- `message:send`: validate and persist a message, then acknowledge the sender and broadcast to the other participant
- `message:delivered`: recipient confirms receipt and persists `delivered_at`
- `messages:read`: advance the participant's read marker and notify the other participant
- `chat:sync`: retrieve messages missed after a known message ID

Server to client:

- `system:ready`: authenticated identity, other participant, and current presence
- `message:new`: newly persisted incoming message
- `message:delivered`: delivery timestamp for an outgoing message
- `messages:read`: the other participant's latest read marker
- `presence:changed`: online or offline transition

## Reliability Rules

- A message is written to PostgreSQL before `message:new` is broadcast.
- `clientMessageId` prevents duplicate inserts and duplicate broadcasts during retries.
- Presence counts every active tab and device; offline is emitted only after the last socket disconnects.
- New socket handshakes revalidate the database session.
- `chat:sync` recovers missed messages after reconnection.

## Current Limitation

The backend is live and complete, but `/chat` remains a placeholder. Stage 7 connects the browser interface to these APIs and events.
