import { getDatabasePool, requireDatabaseUrl } from "../config/database.js";

function db(client) {
  const value = client || getDatabasePool();
  if (!value) requireDatabaseUrl();
  return value;
}

const messageSelect = `
  SELECT m.id, m.client_message_id, m.sender_id, p.identity_key AS sender_identity_key,
         p.display_name AS sender_display_name, m.message_text, m.reply_to_message_id,
         m.created_at, m.delivered_at,
         rm.message_text AS reply_message_text, rm.sender_id AS reply_sender_id,
         rp.display_name AS reply_sender_display_name
  FROM messages m
  JOIN participants p ON p.id = m.sender_id
  LEFT JOIN messages rm ON rm.id = m.reply_to_message_id
  LEFT JOIN participants rp ON rp.id = rm.sender_id`;

export async function findMessageById(id, client) {
  const { rows } = await db(client).query(`${messageSelect} WHERE m.id = $1`, [id]);
  return rows[0] || null;
}

export async function findMessageByClientId(senderId, clientMessageId, client) {
  const { rows } = await db(client).query(`${messageSelect} WHERE m.sender_id = $1 AND m.client_message_id = $2`, [senderId, clientMessageId]);
  return rows[0] || null;
}

export async function insertMessage({ senderId, clientMessageId, text, replyToMessageId }, client) {
  const { rows } = await db(client).query(`
    INSERT INTO messages (sender_id, client_message_id, message_text, reply_to_message_id)
    VALUES ($1, $2, $3, $4)
    ON CONFLICT (sender_id, client_message_id) DO NOTHING
    RETURNING id`, [senderId, clientMessageId, text, replyToMessageId]);
  return rows[0]?.id || null;
}

export async function listMessagesBefore({ beforeId, limit }) {
  const values = [];
  let where = "";
  if (beforeId) {
    values.push(beforeId);
    where = `WHERE (m.created_at, m.id) < (SELECT created_at, id FROM messages WHERE id = $1)`;
  }
  values.push(limit + 1);
  const { rows } = await db().query(`${messageSelect} ${where} ORDER BY m.created_at DESC, m.id DESC LIMIT $${values.length}`, values);
  return rows;
}

export async function listMessagesAfter({ afterId, limit }) {
  const values = [];
  let where = "";
  if (afterId) {
    values.push(afterId);
    where = `WHERE (m.created_at, m.id) > (SELECT created_at, id FROM messages WHERE id = $1)`;
  }
  values.push(limit + 1);
  const { rows } = await db().query(`${messageSelect} ${where} ORDER BY m.created_at ASC, m.id ASC LIMIT $${values.length}`, values);
  return rows;
}

export async function getParticipantState(participantId, client) {
  const { rows } = await db(client).query(`
    SELECT ps.participant_id, ps.last_read_message_id, ps.last_read_at,
           m.created_at AS last_read_message_created_at
    FROM participant_state ps
    LEFT JOIN messages m ON m.id = ps.last_read_message_id
    WHERE ps.participant_id = $1`, [participantId]);
  return rows[0] || null;
}

export async function advanceReadMarker(participantId, messageId, client) {
  const { rows } = await db(client).query(`
    UPDATE participant_state ps
    SET last_read_message_id = candidate.id, last_read_at = NOW()
    FROM messages candidate
    LEFT JOIN messages current_message ON current_message.id = ps.last_read_message_id
    WHERE ps.participant_id = $1
      AND candidate.id = $2
      AND (current_message.id IS NULL OR (candidate.created_at, candidate.id) > (current_message.created_at, current_message.id))
    RETURNING ps.participant_id, ps.last_read_message_id, ps.last_read_at`, [participantId, messageId]);
  return rows[0] || null;
}

export async function getUnreadCount(participantId) {
  const { rows } = await db().query(`
    SELECT COUNT(*)::int AS unread_count
    FROM messages m
    JOIN participant_state ps ON ps.participant_id = $1
    LEFT JOIN messages read_message ON read_message.id = ps.last_read_message_id
    WHERE m.sender_id <> $1
      AND (read_message.id IS NULL OR (m.created_at, m.id) > (read_message.created_at, read_message.id))`, [participantId]);
  return rows[0]?.unread_count || 0;
}
