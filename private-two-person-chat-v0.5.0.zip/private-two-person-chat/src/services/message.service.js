import { env } from "../config/env.js";
import { withTransaction } from "../config/database.js";
import { AppError } from "../utils/app-error.js";
import {
  advanceReadMarker, findMessageByClientId, findMessageById, getParticipantState,
  getUnreadCount, insertMessage, listMessagesAfter, listMessagesBefore
} from "../repositories/message.repository.js";

function mapMessage(row) {
  return {
    id: row.id,
    clientMessageId: row.client_message_id,
    sender: { id: row.sender_id, identityKey: row.sender_identity_key, displayName: row.sender_display_name },
    text: row.message_text,
    replyTo: row.reply_to_message_id ? {
      id: row.reply_to_message_id,
      senderId: row.reply_sender_id,
      senderDisplayName: row.reply_sender_display_name,
      text: row.reply_message_text
    } : null,
    createdAt: row.created_at,
    deliveredAt: row.delivered_at
  };
}

function cappedLimit(requested, fallback, maximum) {
  return Math.min(requested || fallback, maximum);
}

export async function createTextMessage(participantId, payload) {
  return withTransaction(async (client) => {
    if (payload.replyToMessageId) {
      const replied = await findMessageById(payload.replyToMessageId, client);
      if (!replied) throw new AppError(400, "INVALID_REPLY", "The message being replied to no longer exists.");
    }

    const insertedId = await insertMessage({
      senderId: participantId,
      clientMessageId: payload.clientMessageId,
      text: payload.text.trim(),
      replyToMessageId: payload.replyToMessageId
    }, client);

    const row = insertedId
      ? await findMessageById(insertedId, client)
      : await findMessageByClientId(participantId, payload.clientMessageId, client);

    if (!row) throw new AppError(500, "MESSAGE_PERSISTENCE_FAILED", "The message could not be stored.");
    return { message: mapMessage(row), duplicate: !insertedId };
  });
}

export async function getMessageHistory(participantId, query) {
  if (query.before && !await findMessageById(query.before)) throw new AppError(400, "INVALID_CURSOR", "The message cursor is invalid.");
  const limit = cappedLimit(query.limit, env.MESSAGE_HISTORY_DEFAULT_LIMIT, env.MESSAGE_HISTORY_MAX_LIMIT);
  const rows = await listMessagesBefore({ beforeId: query.before, limit });
  const hasMore = rows.length > limit;
  const page = rows.slice(0, limit).reverse().map(mapMessage);
  const [state, unreadCount] = await Promise.all([getParticipantState(participantId), getUnreadCount(participantId)]);
  return {
    messages: page,
    pageInfo: { hasMore, nextBefore: hasMore && page.length ? page[0].id : null },
    readState: { lastReadMessageId: state?.last_read_message_id || null, lastReadAt: state?.last_read_at || null },
    unreadCount
  };
}

export async function syncMessages(participantId, query) {
  if (query.after && !await findMessageById(query.after)) throw new AppError(400, "INVALID_CURSOR", "The synchronization cursor is invalid.");
  const limit = cappedLimit(query.limit, env.MESSAGE_SYNC_MAX_LIMIT, env.MESSAGE_SYNC_MAX_LIMIT);
  const rows = await listMessagesAfter({ afterId: query.after, limit });
  const hasMore = rows.length > limit;
  const messages = rows.slice(0, limit).map(mapMessage);
  const [state, unreadCount] = await Promise.all([getParticipantState(participantId), getUnreadCount(participantId)]);
  return {
    messages,
    pageInfo: { hasMore, nextAfter: hasMore && messages.length ? messages[messages.length - 1].id : null },
    readState: { lastReadMessageId: state?.last_read_message_id || null, lastReadAt: state?.last_read_at || null },
    unreadCount
  };
}

export async function markMessagesRead(participantId, messageId) {
  const target = await findMessageById(messageId);
  if (!target) throw new AppError(404, "MESSAGE_NOT_FOUND", "The message was not found.");
  const updated = await advanceReadMarker(participantId, messageId);
  const state = updated || await getParticipantState(participantId);
  return { lastReadMessageId: state?.last_read_message_id || null, lastReadAt: state?.last_read_at || null };
}
