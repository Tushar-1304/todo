import { createTextMessage, getMessageHistory, markMessagesRead, syncMessages } from "../services/message.service.js";

export async function createMessage(req, res) {
  const result = await createTextMessage(req.auth.participant.id, req.validatedBody);
  return res.status(result.duplicate ? 200 : 201).json({ success: true, data: result });
}
export async function listMessages(req, res) {
  return res.json({ success: true, data: await getMessageHistory(req.auth.participant.id, req.validatedQuery) });
}
export async function syncMessageHistory(req, res) {
  return res.json({ success: true, data: await syncMessages(req.auth.participant.id, req.validatedQuery) });
}
export async function readMessages(req, res) {
  return res.json({ success: true, data: await markMessagesRead(req.auth.participant.id, req.validatedBody.messageId) });
}
