function invalid(res) {
  return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", message: "The submitted information is invalid." } });
}
export function validateBody(schema) {
  return (req, res, next) => {
    const result = schema.safeParse(req.body);
    if (!result.success) return invalid(res);
    req.validatedBody = result.data;
    return next();
  };
}
export function validateQuery(schema) {
  return (req, res, next) => {
    const result = schema.safeParse(req.query);
    if (!result.success) return invalid(res);
    req.validatedQuery = result.data;
    return next();
  };
}
