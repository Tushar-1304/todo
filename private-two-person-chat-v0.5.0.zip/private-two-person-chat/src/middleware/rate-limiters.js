import { rateLimit } from "express-rate-limit";
import { env } from "../config/env.js";
const response={success:false,error:{code:"RATE_LIMITED",message:"Too many attempts. Please wait and try again."}};
export const accessRateLimiter=rateLimit({windowMs:env.ACCESS_RATE_LIMIT_WINDOW_MS,limit:env.ACCESS_RATE_LIMIT_MAX,standardHeaders:"draft-8",legacyHeaders:false,skipSuccessfulRequests:true,message:response,keyGenerator:(req)=>`${req.ip}:${req.body?.identity||"unknown"}`});
export const sessionRateLimiter=rateLimit({windowMs:env.SESSION_RATE_LIMIT_WINDOW_MS,limit:env.SESSION_RATE_LIMIT_MAX,standardHeaders:"draft-8",legacyHeaders:false,message:response});

export const messageRateLimiter=rateLimit({
  windowMs:env.MESSAGE_RATE_LIMIT_WINDOW_MS,
  limit:env.MESSAGE_RATE_LIMIT_MAX,
  standardHeaders:"draft-8",
  legacyHeaders:false,
  message:{success:false,error:{code:"MESSAGE_RATE_LIMITED",message:"You are sending messages too quickly. Please pause briefly."}},
  keyGenerator:(req)=>req.auth?.participant?.id||req.ip
});
