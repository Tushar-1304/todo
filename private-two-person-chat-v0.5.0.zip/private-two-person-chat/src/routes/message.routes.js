import { Router } from "express";
import { createMessage, listMessages, readMessages, syncMessageHistory } from "../controllers/message.controller.js";
import { authenticate } from "../middleware/authenticate.js";
import { messageRateLimiter } from "../middleware/rate-limiters.js";
import { validateBody, validateQuery } from "../middleware/validate.js";
import { asyncHandler } from "../utils/async-handler.js";
import { createMessageSchema, historyQuerySchema, readMessageSchema, syncQuerySchema } from "../validators/message.validators.js";

export const messageRouter = Router();
messageRouter.use(asyncHandler(authenticate));
messageRouter.get("/", validateQuery(historyQuerySchema), asyncHandler(listMessages));
messageRouter.get("/sync", validateQuery(syncQuerySchema), asyncHandler(syncMessageHistory));
messageRouter.post("/", messageRateLimiter, validateBody(createMessageSchema), asyncHandler(createMessage));
messageRouter.post("/read", validateBody(readMessageSchema), asyncHandler(readMessages));
