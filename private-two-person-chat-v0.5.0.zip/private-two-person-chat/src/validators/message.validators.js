import { z } from "zod";

const uuid = z.string().uuid();

export const createMessageSchema = z.object({
  clientMessageId: uuid,
  text: z.string().max(2000).refine((value) => value.trim().length > 0, "Message cannot be blank."),
  replyToMessageId: uuid.nullish().transform((value) => value || null)
}).strict();

export const readMessageSchema = z.object({ messageId: uuid }).strict();

export const historyQuerySchema = z.object({
  before: uuid.optional(),
  limit: z.coerce.number().int().min(1).optional()
}).strict();

export const syncQuerySchema = z.object({
  after: uuid.optional(),
  limit: z.coerce.number().int().min(1).optional()
}).strict();
