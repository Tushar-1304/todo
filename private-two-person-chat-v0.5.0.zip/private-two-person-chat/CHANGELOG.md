# Changelog

## 0.5.0 - 2026-09-23
- Added authenticated message creation with idempotent client message IDs
- Added cursor-based older history and forward reconnection synchronization
- Added reply validation and reply-preview response data
- Added read markers that cannot move backward
- Added unread incoming-message counts
- Added message rate limiting and payload/query validation
- Added message consistency migration and tests

## 0.4.0 - 2026-09-23
- Added identity frontend, session restoration, accessible states, and same-origin API client

## 0.3.0 - 2026-09-23
- Added Argon2id access verification, opaque sessions, HTTP-only cookies, logout, validation, and rate limiting

## 0.2.0 - 2026-09-23
- Added checksum migrations, PostgreSQL schema, indexes, and participant seeds

## 0.1.0 - 2026-09-23
- Added application foundation, Express, Socket.IO, security headers, and tracking docs
