CREATE OR REPLACE FUNCTION prevent_self_reply()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.reply_to_message_id = NEW.id THEN
    RAISE EXCEPTION 'A message cannot reply to itself';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS messages_prevent_self_reply ON messages;
CREATE TRIGGER messages_prevent_self_reply
BEFORE INSERT OR UPDATE OF reply_to_message_id ON messages
FOR EACH ROW EXECUTE FUNCTION prevent_self_reply();

CREATE INDEX IF NOT EXISTS messages_forward_cursor_idx ON messages (created_at ASC, id ASC);
