# Stage 5 Manual Test Checklist

- [ ] Install dependencies and complete Stage 4 environment setup
- [ ] Run `npm run db:migrate` and confirm migration 005 is applied
- [ ] Run `npm test` and `npm run check`
- [ ] Authenticate Tushar in one browser and Friend in a private browser
- [ ] `POST /api/messages` creates a text message as the authenticated participant
- [ ] Repeating the same `clientMessageId` returns the existing message without duplication
- [ ] Blank and oversized messages return HTTP 400
- [ ] A reply to a valid message is stored with reply preview data
- [ ] An invalid reply UUID or missing message is rejected
- [ ] `GET /api/messages?limit=30` returns chronological display order
- [ ] `before=<messageId>` loads older records without overlap
- [ ] `GET /api/messages/sync?after=<messageId>` returns newer records
- [ ] `POST /api/messages/read` advances the read marker
- [ ] Reading an older message does not move the marker backward
- [ ] Unread count includes only messages sent by the other participant after the marker
