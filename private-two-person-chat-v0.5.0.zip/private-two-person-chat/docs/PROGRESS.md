# Project Progress

## Stages 0-4
- [x] Requirements, application foundation, database, secure sessions, and identity frontend

## Stage 5: Message Storage and History
- [x] Authenticated message REST routes
- [x] Message insertion and server-side sender identity
- [x] Client-message UUID idempotency
- [x] Plain-text validation and 2,000-character limit
- [x] Reply-target validation and reply previews
- [x] Stable cursor-based older-history pagination
- [x] Forward synchronization after reconnection
- [x] Read markers that cannot move backward
- [x] Unread incoming-message calculation
- [x] Message-specific rate limiting
- [x] Invalid-cursor and missing-message handling
- [x] Database forward-cursor index and self-reply protection
- [x] Validation and schema tests
- [ ] Owner API/database verification

## Stage 6: Real-Time Communication
- [ ] Socket cookie authentication
- [ ] Live delivery, acknowledgements, presence, and read events
- [ ] Reconnection synchronization wiring
