import test from "node:test";
import assert from "node:assert/strict";
import { createMessageSchema, historyQuerySchema, readMessageSchema, syncQuerySchema } from "../src/validators/message.validators.js";

const uuid = "550e8400-e29b-41d4-a716-446655440000";
test("valid text message is accepted and blank text is rejected", () => {
  assert.equal(createMessageSchema.safeParse({ clientMessageId: uuid, text: "Hello", replyToMessageId: null }).success, true);
  assert.equal(createMessageSchema.safeParse({ clientMessageId: uuid, text: "   " }).success, false);
});
test("messages over 2000 characters are rejected", () => {
  assert.equal(createMessageSchema.safeParse({ clientMessageId: uuid, text: "x".repeat(2001) }).success, false);
});
test("read marker requires a UUID", () => {
  assert.equal(readMessageSchema.safeParse({ messageId: uuid }).success, true);
  assert.equal(readMessageSchema.safeParse({ messageId: "not-a-uuid" }).success, false);
});
test("history and sync queries accept valid cursors and numeric strings", () => {
  assert.equal(historyQuerySchema.safeParse({ before: uuid, limit: "30" }).success, true);
  assert.equal(syncQuerySchema.safeParse({ after: uuid, limit: "100" }).success, true);
});
