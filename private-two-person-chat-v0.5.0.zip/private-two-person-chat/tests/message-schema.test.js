import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";

test("message schema has idempotency, reply, length, and cursor protections", async () => {
  const core = await fs.readFile("database/migrations/002_create_core_schema.sql", "utf8");
  const consistency = await fs.readFile("database/migrations/005_message_consistency.sql", "utf8");
  assert.match(core, /UNIQUE \(sender_id, client_message_id\)/);
  assert.match(core, /reply_to_message_id UUID REFERENCES messages/);
  assert.match(core, /char_length\(message_text\) <= 2000/);
  assert.match(consistency, /messages_forward_cursor_idx/);
});
