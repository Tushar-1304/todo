# Private Two-Person Chat

Version 0.5.0 adds authenticated message persistence, history pagination, replies, read markers, unread counts, and reconnect synchronization APIs.

## Upgrade

```bash
npm install
npm run db:migrate
npm run db:seed
npm test
npm run check
npm run dev
```

Migration `005_message_consistency.sql` adds a forward cursor index and database self-reply protection.

## Message API

All routes require the HTTP-only authenticated session cookie.

### Create or safely retry a message

`POST /api/messages`

```json
{
  "clientMessageId": "550e8400-e29b-41d4-a716-446655440000",
  "text": "Hello",
  "replyToMessageId": null
}
```

A new message returns HTTP 201. Reusing the same `clientMessageId` for the same authenticated sender returns the original message with HTTP 200 and `duplicate: true`.

### Load newest or older history

```text
GET /api/messages?limit=30
GET /api/messages?before=<oldest-message-id>&limit=30
```

The response is in oldest-to-newest display order. `pageInfo.nextBefore` identifies the next older-history cursor.

### Synchronize after reconnecting

```text
GET /api/messages/sync?after=<newest-local-message-id>&limit=200
```

The response contains messages newer than the supplied cursor in chronological order.

### Advance the read marker

`POST /api/messages/read`

```json
{ "messageId": "message-uuid" }
```

The marker advances only when the target message is newer than the participant's current marker.

## Data Rules

- Sender identity always comes from the authenticated session.
- Messages are trimmed, cannot be blank, and are limited to 2,000 characters.
- PostgreSQL stores a unique pair of `sender_id` and `client_message_id` to prevent duplicate retries.
- Reply targets must exist.
- The database is the source of truth.

## Current Limitation

Stage 5 exposes REST persistence and recovery. Live Socket.IO delivery, presence, delivery acknowledgement, and real-time read events arrive in Stage 6.
