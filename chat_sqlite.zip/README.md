# Private Chat

A private, real-time, text-only conversation for exactly **Tushar** and **Friend**. The application uses one authoritative server-side SQLite database, Express, Socket.IO, Argon2id access verification, opaque HttpOnly sessions, and a responsive vanilla JavaScript interface.

## Quick start

Node.js 20 or 22 LTS is recommended. If native modules cannot use prebuilt binaries, install Python 3, `make`, and a C/C++ compiler (`build-essential` on Ubuntu or Visual Studio Build Tools on Windows).

```bash
npm install
cp .env.example .env
npm run access-hash
npm run access-hash
# Put the two hashes and a random 32+ character SESSION_HASH_PEPPER in .env
npm run migrate
npm run seed
npm run check
npm run dev
```

PowerShell: `Copy-Item .env.example .env`. Open `http://localhost:3000`; use a normal browser window for Tushar and an incognito window for Friend.

## Architecture and security

One long-lived `better-sqlite3` connection is the source of truth for participants, sessions, messages, delivery timestamps, read markers, and migrations. Do not run multiple application instances against this file. Use a persistent local disk, not an ephemeral or network filesystem. WAL mode, foreign keys, busy timeout, prepared statements, and short transactions are enabled. `synchronous=NORMAL` offers good performance but can lose the newest committed transaction after an OS or power failure; configure `FULL` for stronger durability.

Access codes are never committed or stored in SQLite. Environment variables contain Argon2id hashes. Successful verification creates a random 256-bit token; only SHA-256(token + pepper) is stored. The raw token exists only in an HttpOnly, SameSite=Lax cookie, with Secure enabled in production. Changing the pepper invalidates all sessions. Message sender identity comes exclusively from the session. User text is rendered with `textContent`, never `innerHTML`.

REST routes: `POST /api/access/verify`, `GET /api/session`, `POST /api/session/logout`, `GET /api/messages`, `GET /api/messages/sync`, `POST /api/messages/read`, and `GET /health`.

Socket events: `message:send`, `message:delivered`, `messages:read`, `chat:sync`, `message:new`, `message:delivered`, `messages:read`, and `presence:changed`. Messages are persisted before broadcast. `(sender_id, client_message_id)` prevents duplicate inserts. A monotonic sequence supports stable pagination and read-marker advancement.

## Commands

```bash
npm run dev
npm start
npm test
npm run test:coverage
npm run migrate
npm run seed
npm run db:reset -- --force
npm run session:revoke-all
npm run access-hash
npm run backup
npm run backup:verify -- /absolute/path/in/backup/directory.sqlite
npm run backup:prune
npm run restore -- /absolute/path/in/backup/directory.sqlite --app-stopped
npm run check
```

## Backups and recovery

Backups use the SQLite online backup API and `PRAGMA integrity_check`. They contain message content and session-token hashes, so encrypt them and copy them off the application machine. Schedule `npm run backup` with cron or Windows Task Scheduler. Tools such as age, GPG, restic, or rclone can encrypt and transfer files without adding an unused SDK.

For restore: stop the app fully, verify the backup, run the restore command with `--app-stopped`, then restart. The script creates a precautionary backup of the current database. Restore is never exposed over HTTP.

## Deployment

Use one instance, WebSocket support, HTTPS, and persistent local disk. Build with `npm ci --omit=dev`, start with `npm start`, and monitor `/health`.

- **Render:** attach a Persistent Disk and set absolute database/backup paths under its mount. Keep one instance.
- **Northflank:** attach one persistent volume to one replica.
- **Ubuntu VM:** use Node.js LTS, PM2, Nginx, Certbot, and UFW. Proxy WebSocket upgrade headers, set `TRUST_PROXY=1`, allow OpenSSH and `Nginx Full`, run `pm2 start server.js --name private-chat`, and schedule encrypted off-machine backups with cron.

Nginx needs `proxy_http_version 1.1`, `proxy_set_header Upgrade $http_upgrade`, `proxy_set_header Connection "upgrade"`, `proxy_set_header Host $host`, and `proxy_set_header X-Forwarded-Proto $scheme`.

## Limits and troubleshooting

Defaults are 30-day sessions, 30 initial messages, 50 maximum page size, 2,000 Unicode code points, five failed access attempts per 15 minutes, and about 30 messages per minute per participant. In-memory limiter state resets on restart. If login loops in production, verify HTTPS, `APP_URL`, and `TRUST_PROXY`. If data disappears, the host is using ephemeral storage. `SQLITE_BUSY` usually means multiple processes or an unsuitable filesystem.

## Manual two-browser checklist

- Verify both identities and incorrect-code handling.
- Refresh to test session restoration; log out to test revocation.
- Send both directions, reply, and verify sent, delivered, read, and presence states.
- Open a second tab and ensure closing one tab does not mark the participant offline.
- Disconnect networking, reconnect, and verify missed-message synchronization and duplicate prevention.
- Create more than 30 messages and load older pages.
- Send literal `<img src=x onerror=alert(1)>`; it must display as text.
- Restart Node and confirm persistence.
- Create and verify a backup; test restore only after stopping the app.

## Known limitations and future work

There is no end-to-end encryption, attachment support, push notification, edit/delete, or exact last-seen history. SQLite does not support horizontal scaling in this design. A future PostgreSQL migration should retain UUIDs and sequence ordering and move presence/rate limiting to Redis.
