import test from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import { createApp } from "../src/app.js";
test("GET /health returns a safe response without configured database", async () => { const r=await request(createApp()).get("/health"); assert.equal(r.status,200); assert.equal(r.body.status,"ok"); assert.equal(r.body.version,"0.2.0"); });
test("unknown API route returns structured JSON", async () => { const r=await request(createApp()).get("/api/unknown"); assert.equal(r.status,404); assert.equal(r.body.error.code,"NOT_FOUND"); });
