import test from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
process.env.SESSION_TOKEN_PEPPER="test-pepper-with-more-than-thirty-two-characters";
const {createSessionToken,hashSessionToken}=await import("../src/utils/crypto.js");
test("session tokens have high entropy and hash deterministically",()=>{const a=createSessionToken(),b=createSessionToken();assert.notEqual(a,b);assert.ok(a.length>=64);assert.equal(hashSessionToken(a),hashSessionToken(a));assert.match(hashSessionToken(a),/^[0-9a-f]{64}$/);});
test("session-token hashes differ for different tokens",()=>{assert.notEqual(hashSessionToken(crypto.randomBytes(32).toString("hex")),hashSessionToken(crypto.randomBytes(32).toString("hex")));});
