import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";

test("access page provides required identity and code controls", async () => {
  const html = await fs.readFile("public/index.html", "utf8");
  for (const expected of ['value="tushar"', 'value="friend"', 'id="access-code"', 'id="toggle-code"', 'id="continue-button"', 'id="form-message"']) assert.ok(html.includes(expected), expected);
});

test("frontend uses same-origin API routes", async () => {
  const api = await fs.readFile("public/js/api.js", "utf8");
  assert.ok(api.includes('"/api/session"'));
  assert.ok(api.includes('"/api/access/verify"'));
  assert.ok(!api.includes("onrender.com"));
  assert.ok(!api.includes("localhost:3000/api"));
});

test("message rendering code is not introduced through unsafe HTML", async () => {
  const access = await fs.readFile("public/js/access.js", "utf8");
  assert.ok(!access.includes("innerHTML"));
  assert.ok(access.includes("textContent"));
});
