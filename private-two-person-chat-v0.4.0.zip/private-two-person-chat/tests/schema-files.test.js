import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
const files = ["database/migrations/001_enable_extensions.sql","database/migrations/002_create_core_schema.sql","database/migrations/003_core_triggers.sql","database/seeds/001_participants.sql"];
test("required database SQL files exist and are non-empty", async () => { for (const file of files) assert.ok((await fs.readFile(file,"utf8")).trim().length > 20, file); });
test("schema includes participant, session, message, and state tables", async () => { const sql = await fs.readFile("database/migrations/002_create_core_schema.sql","utf8"); for (const table of ["participants","sessions","messages","participant_state"]) assert.match(sql,new RegExp(`CREATE TABLE IF NOT EXISTS ${table}`)); });
test("seed defines exactly the two required identities", async () => { const sql = await fs.readFile("database/seeds/001_participants.sql","utf8"); assert.match(sql,/\('tushar', 'Tushar'\)/); assert.match(sql,/\('friend', 'Friend'\)/); });
