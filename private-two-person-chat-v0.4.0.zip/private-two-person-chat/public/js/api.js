(function () {
  async function request(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");

    let response;
    try {
      response = await fetch(path, { ...options, headers, credentials: "same-origin" });
    } catch {
      throw { code: "NETWORK_ERROR", message: "The server could not be reached. Check your connection and try again.", status: 0 };
    }

    const data = response.status === 204 ? null : await response.json().catch(() => null);
    if (!response.ok) {
      throw {
        code: data?.error?.code || "REQUEST_FAILED",
        message: data?.error?.message || "The request could not be completed.",
        status: response.status
      };
    }
    return data;
  }

  window.privateChatApi = Object.freeze({
    getSession: () => request("/api/session"),
    verifyAccess: (identity, accessCode) => request("/api/access/verify", {
      method: "POST",
      body: JSON.stringify({ identity, accessCode })
    }),
    logout: () => request("/api/session/logout", { method: "POST" })
  });
})();
