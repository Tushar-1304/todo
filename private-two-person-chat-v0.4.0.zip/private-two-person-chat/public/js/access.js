(function () {
  const restoringState = document.querySelector("#restoring-state");
  const form = document.querySelector("#access-form");
  const codeInput = document.querySelector("#access-code");
  const toggleCodeButton = document.querySelector("#toggle-code");
  const continueButton = document.querySelector("#continue-button");
  const message = document.querySelector("#form-message");
  const buttonLabel = continueButton.querySelector(".button-label");
  const buttonSpinner = continueButton.querySelector(".button-spinner");
  const identityInputs = [...document.querySelectorAll('input[name="identity"]')];

  let submitting = false;

  function selectedIdentity() {
    return identityInputs.find((input) => input.checked)?.value || null;
  }

  function displayMessage(text = "", type = "error") {
    message.textContent = text;
    message.dataset.type = text ? type : "";
  }

  function setSubmitting(value) {
    submitting = value;
    identityInputs.forEach((input) => { input.disabled = value; });
    codeInput.disabled = value || !selectedIdentity();
    toggleCodeButton.disabled = codeInput.disabled;
    continueButton.disabled = value || !selectedIdentity() || !codeInput.value.trim();
    buttonLabel.textContent = value ? "Verifying..." : "Enter private chat";
    buttonSpinner.hidden = !value;
    form.setAttribute("aria-busy", String(value));
  }

  function updateFormAvailability() {
    const available = Boolean(selectedIdentity());
    codeInput.disabled = !available || submitting;
    toggleCodeButton.disabled = !available || submitting;
    continueButton.disabled = !available || submitting || !codeInput.value.trim();
    if (available && !submitting) codeInput.focus({ preventScroll: true });
    displayMessage();
  }

  async function restoreSession() {
    try {
      await window.privateChatApi.getSession();
      window.location.replace("/chat");
    } catch (error) {
      if (error.status !== 401 && error.code !== "NETWORK_ERROR") {
        displayMessage("The session check could not be completed. You can still try your private access code.", "warning");
      } else if (error.code === "NETWORK_ERROR") {
        displayMessage(error.message, "warning");
      }
      restoringState.hidden = true;
      form.hidden = false;
      identityInputs[0].focus();
    }
  }

  identityInputs.forEach((input) => input.addEventListener("change", updateFormAvailability));
  codeInput.addEventListener("input", () => {
    continueButton.disabled = submitting || !selectedIdentity() || !codeInput.value.trim();
    displayMessage();
  });

  toggleCodeButton.addEventListener("click", () => {
    const willShow = codeInput.type === "password";
    codeInput.type = willShow ? "text" : "password";
    toggleCodeButton.setAttribute("aria-pressed", String(willShow));
    toggleCodeButton.setAttribute("aria-label", willShow ? "Hide access code" : "Show access code");
    toggleCodeButton.querySelector(".show-label").textContent = willShow ? "Hide" : "Show";
    codeInput.focus();
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const identity = selectedIdentity();
    const accessCode = codeInput.value;
    if (!identity) return displayMessage("Choose Tushar or Friend before continuing.");
    if (!accessCode.trim()) return displayMessage("Enter your private access code.");

    setSubmitting(true);
    displayMessage();
    try {
      await window.privateChatApi.verifyAccess(identity, accessCode);
      displayMessage("Access verified. Opening your private chat...", "success");
      window.location.replace("/chat");
    } catch (error) {
      const friendly = error.status === 429
        ? "Too many attempts. Wait a few minutes before trying again."
        : error.code === "NETWORK_ERROR"
          ? error.message
          : "That identity and private access code did not match. Try again.";
      displayMessage(friendly);
      codeInput.select();
      setSubmitting(false);
    }
  });

  restoreSession();
})();
