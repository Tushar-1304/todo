import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { getDatabasePool, requireDatabaseUrl, closeDatabasePool } from "../src/config/database.js";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
async function main() {
  requireDatabaseUrl();
  const pool = getDatabasePool();
  const directory = path.join(root, "database", "seeds");
  const files = (await fs.readdir(directory)).filter((f) => f.endsWith(".sql")).sort();
  for (const file of files) {
    await pool.query(await fs.readFile(path.join(directory, file), "utf8"));
    console.log(`seeded   ${file}`);
  }
  const { rows } = await pool.query("SELECT identity_key, display_name FROM participants ORDER BY identity_key");
  if (rows.length !== 2 || !rows.some((r) => r.identity_key === "tushar") || !rows.some((r) => r.identity_key === "friend")) throw new Error("Participant seed verification failed.");
  console.log("verified exactly two predefined participants");
}
main().catch((error) => { console.error(`Seed failed: ${error.message}`); process.exitCode = 1; }).finally(closeDatabasePool);
