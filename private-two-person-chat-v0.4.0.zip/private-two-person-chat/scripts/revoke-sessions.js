import readline from "node:readline/promises";
import { stdin as input,stdout as output } from "node:process";
import { revokeAllSessions } from "../src/repositories/session.repository.js";
import { closeDatabasePool, requireDatabaseUrl } from "../src/config/database.js";
const rl=readline.createInterface({input,output});
async function main(){requireDatabaseUrl();const answer=await rl.question('Type REVOKE ALL to invalidate every active browser session: ');if(answer!=="REVOKE ALL"){console.log("Cancelled.");return;}console.log(`Revoked ${await revokeAllSessions()} session(s).`);}
main().catch(e=>{console.error(`Revocation failed: ${e.message}`);process.exitCode=1;}).finally(async()=>{rl.close();await closeDatabasePool();});
