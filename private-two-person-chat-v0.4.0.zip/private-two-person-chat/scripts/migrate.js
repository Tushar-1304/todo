import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";
import { getDatabasePool, requireDatabaseUrl, closeDatabasePool } from "../src/config/database.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const migrationDirectory = path.join(root, "database", "migrations");
const statusOnly = process.argv.includes("--status");

async function checksum(content) { return crypto.createHash("sha256").update(content).digest("hex"); }
async function main() {
  requireDatabaseUrl();
  const pool = getDatabasePool();
  await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
    filename TEXT PRIMARY KEY,
    checksum CHAR(64) NOT NULL,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  const files = (await fs.readdir(migrationDirectory)).filter((f) => f.endsWith(".sql")).sort();
  const applied = new Map((await pool.query("SELECT filename, checksum, applied_at FROM schema_migrations ORDER BY filename")).rows.map((r) => [r.filename, r]));
  if (statusOnly) {
    for (const file of files) console.log(`${applied.has(file) ? "applied" : "pending"}  ${file}`);
    return;
  }
  for (const file of files) {
    const sql = await fs.readFile(path.join(migrationDirectory, file), "utf8");
    const hash = await checksum(sql);
    const prior = applied.get(file);
    if (prior) {
      if (prior.checksum !== hash) throw new Error(`Applied migration was modified: ${file}`);
      console.log(`skip     ${file}`);
      continue;
    }
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations (filename, checksum) VALUES ($1, $2)", [file, hash]);
      await client.query("COMMIT");
      console.log(`applied  ${file}`);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally { client.release(); }
  }
}
main().catch((error) => { console.error(`Migration failed: ${error.message}`); process.exitCode = 1; }).finally(closeDatabasePool);
