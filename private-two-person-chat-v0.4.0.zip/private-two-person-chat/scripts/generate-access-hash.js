import readline from "node:readline/promises";
import { stdin as input,stdout as output } from "node:process";
import argon2 from "argon2";
const rl=readline.createInterface({input,output});
async function main(){
  if(!input.isTTY)throw new Error("Run this script in an interactive terminal.");
  output.write("Enter a private access code. Input will be hidden where the terminal supports it.\n");
  const code=await rl.question("Access code: ");
  if(code.length<12)throw new Error("Use an access code with at least 12 characters.");
  const hash=await argon2.hash(code,{type:argon2.argon2id,memoryCost:19456,timeCost:2,parallelism:1});
  output.write(`\nGenerated Argon2id hash:\n${hash}\n`);
}
main().catch(e=>{console.error(`Hash generation failed: ${e.message}`);process.exitCode=1;}).finally(()=>rl.close());
