import fs from "node:fs/promises";
import path from "node:path";
import { spawnSync } from "node:child_process";

const ignored = new Set(["node_modules", ".git"]);
async function collect(directory) {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const results = [];
  for (const entry of entries) {
    if (ignored.has(entry.name)) continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) results.push(...await collect(fullPath));
    else if (entry.name.endsWith(".js")) results.push(fullPath);
  }
  return results;
}

const files = await collect(process.cwd());
for (const file of files) {
  const result = spawnSync(process.execPath, ["--check", file], { encoding: "utf8" });
  if (result.status !== 0) {
    console.error(result.stderr || result.stdout);
    process.exit(result.status || 1);
  }
}
console.log(`Syntax check passed for ${files.length} JavaScript files.`);
