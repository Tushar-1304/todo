INSERT INTO participants (identity_key, display_name)
VALUES ('tushar', 'Tushar'), ('friend', 'Friend')
ON CONFLICT (identity_key) DO UPDATE SET display_name = EXCLUDED.display_name;

INSERT INTO participant_state (participant_id)
SELECT id FROM participants WHERE identity_key IN ('tushar', 'friend')
ON CONFLICT (participant_id) DO NOTHING;
