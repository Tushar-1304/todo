ALTER TABLE participants DROP CONSTRAINT IF EXISTS participants_allowed_identity;
ALTER TABLE participants ADD CONSTRAINT participants_allowed_identity CHECK (identity_key IN ('tushar','friend'));
