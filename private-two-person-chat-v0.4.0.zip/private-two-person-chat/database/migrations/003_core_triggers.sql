CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS participants_set_updated_at ON participants;
CREATE TRIGGER participants_set_updated_at BEFORE UPDATE ON participants FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS participant_state_set_updated_at ON participant_state;
CREATE TRIGGER participant_state_set_updated_at BEFORE UPDATE ON participant_state FOR EACH ROW EXECUTE FUNCTION set_updated_at();
