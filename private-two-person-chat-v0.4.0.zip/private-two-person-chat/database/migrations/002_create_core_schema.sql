CREATE TABLE IF NOT EXISTS participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  identity_key VARCHAR(32) NOT NULL UNIQUE,
  display_name VARCHAR(80) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT participants_identity_key_format CHECK (identity_key ~ '^[a-z][a-z0-9_-]{1,31}$'),
  CONSTRAINT participants_display_name_not_blank CHECK (btrim(display_name) <> '')
);

CREATE TABLE IF NOT EXISTS sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  participant_id UUID NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
  token_hash CHAR(64) NOT NULL UNIQUE,
  user_agent VARCHAR(500),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_used_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  CONSTRAINT sessions_token_hash_format CHECK (token_hash ~ '^[0-9a-f]{64}$'),
  CONSTRAINT sessions_expiry_after_creation CHECK (expires_at > created_at),
  CONSTRAINT sessions_revoked_after_creation CHECK (revoked_at IS NULL OR revoked_at >= created_at)
);
CREATE INDEX IF NOT EXISTS sessions_participant_active_idx ON sessions (participant_id, expires_at DESC) WHERE revoked_at IS NULL;
CREATE INDEX IF NOT EXISTS sessions_cleanup_idx ON sessions (expires_at, revoked_at);

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_message_id UUID NOT NULL,
  sender_id UUID NOT NULL REFERENCES participants(id) ON DELETE RESTRICT,
  message_text TEXT NOT NULL,
  reply_to_message_id UUID REFERENCES messages(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  delivered_at TIMESTAMPTZ,
  CONSTRAINT messages_text_not_blank CHECK (btrim(message_text) <> ''),
  CONSTRAINT messages_text_max_length CHECK (char_length(message_text) <= 2000),
  CONSTRAINT messages_delivered_after_creation CHECK (delivered_at IS NULL OR delivered_at >= created_at),
  CONSTRAINT messages_sender_client_unique UNIQUE (sender_id, client_message_id)
);
CREATE INDEX IF NOT EXISTS messages_created_cursor_idx ON messages (created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS messages_sender_idx ON messages (sender_id, created_at DESC);
CREATE INDEX IF NOT EXISTS messages_reply_idx ON messages (reply_to_message_id) WHERE reply_to_message_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS participant_state (
  participant_id UUID PRIMARY KEY REFERENCES participants(id) ON DELETE CASCADE,
  last_read_message_id UUID REFERENCES messages(id) ON DELETE SET NULL,
  last_read_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS participant_state_last_read_idx ON participant_state (last_read_message_id) WHERE last_read_message_id IS NOT NULL;
