import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { env } from "../../src/config/env.js";
import { getDatabasePool, requireDatabaseUrl, closeDatabasePool } from "../../src/config/database.js";
if (env.NODE_ENV === "production") { console.error("Development reset is disabled in production."); process.exit(1); }
const rl = readline.createInterface({ input, output });
async function main() {
  requireDatabaseUrl();
  const answer = await rl.question('Type RESET to delete all project tables from the configured database: ');
  if (answer !== "RESET") { console.log("Reset cancelled."); return; }
  const pool = getDatabasePool();
  await pool.query("DROP TABLE IF EXISTS participant_state, messages, sessions, participants, schema_migrations CASCADE");
  console.log("Development database reset complete. Run npm run db:setup next.");
}
main().catch((error) => { console.error(`Reset failed: ${error.message}`); process.exitCode = 1; }).finally(async () => { rl.close(); await closeDatabasePool(); });
