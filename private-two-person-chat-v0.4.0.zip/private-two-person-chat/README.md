# Private Two-Person Chat

Version 0.4.0 provides the complete browser identity experience on top of the Stage 3 secure, server-managed session system.

## Setup

```bash
npm install
```

Copy `.env.example` to `.env`, configure PostgreSQL, add a 32+ character `SESSION_TOKEN_PEPPER`, and generate separate access-code hashes:

```bash
npm run access:hash
npm run access:hash
npm run db:setup
npm test
npm run check
npm run dev
```

Open `http://localhost:3000`. The page checks for an existing session. If none exists, choose Tushar or Friend, enter the matching private code, and continue.

## Browser Flow

1. `/` calls `GET /api/session` using the same-origin HTTP-only cookie.
2. A valid session redirects immediately to `/chat`.
3. An unauthenticated browser displays the identity form.
4. The form sends `POST /api/access/verify`.
5. Successful verification sets the secure session cookie and redirects to `/chat`.

## Frontend Security

- The browser never receives access-code hashes, database credentials, or session-token hashes.
- The session cookie is HTTP-only and cannot be read by frontend JavaScript.
- API calls use relative same-origin paths.
- User-facing messages use `textContent`, not `innerHTML`.
- Page scripts are local and compatible with the configured Content Security Policy.

## Current Limitation

The `/chat` route remains a placeholder until message storage and real-time communication are implemented in Stages 5 through 7.
