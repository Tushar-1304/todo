# Architecture Decisions

- **Single origin:** Express serves pages, APIs, and Socket.IO from one URL.
- **PostgreSQL:** Stores participants, sessions, messages, replies, and read markers.
- **Opaque sessions:** Future authentication uses random session tokens in HTTP-only cookies; only token hashes are stored.
- **Three ordered migrations:** Extensions, core schema, and triggers are independently tracked by checksum.
- **Idempotent seed:** The participant seed can be rerun safely and verifies exactly two predefined participants.
- **Cursor-ready index:** Messages are ordered by `(created_at DESC, id DESC)` for stable pagination.
