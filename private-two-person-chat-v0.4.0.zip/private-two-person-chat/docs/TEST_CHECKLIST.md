# Stage 4 Manual Test Checklist

- [ ] Complete Stage 3 environment setup
- [ ] Run `npm install`, `npm run db:migrate`, and `npm run db:seed`
- [ ] `npm run check` passes
- [ ] `npm test` passes
- [ ] Opening `/` briefly shows “Checking this device”
- [ ] An unauthenticated browser displays the identity form
- [ ] Access-code input remains disabled until an identity is selected
- [ ] Selecting Tushar enables and focuses the access-code field
- [ ] Selecting Friend works the same way
- [ ] Show and Hide toggles the access-code visibility
- [ ] Blank submission is blocked
- [ ] An incorrect code displays a generic inline error
- [ ] A valid code redirects to `/chat`
- [ ] Revisiting `/` with a valid cookie redirects automatically
- [ ] The form works with keyboard-only navigation
- [ ] Mobile layout displays both identity options without horizontal scrolling
