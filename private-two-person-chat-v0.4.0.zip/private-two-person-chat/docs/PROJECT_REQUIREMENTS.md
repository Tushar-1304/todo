# Project Requirements

Build a secure, private, real-time, text-only chat for exactly two predefined participants: `tushar` and `friend`. It uses one public URL, one permanent conversation, PostgreSQL persistence, Socket.IO real-time delivery, secure opaque sessions, replies, timestamps, delivery/read states, presence, reconnection, and responsive layouts. Public signup, email OTP, search, contacts, groups, media, calls, editing, deletion, reactions, and push notifications are excluded from the MVP.
