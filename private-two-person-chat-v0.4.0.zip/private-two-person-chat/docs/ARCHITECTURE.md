# Architecture

```text
Browser -> Express pages and REST + Socket.IO -> Node.js service -> PostgreSQL
```

The browser and server use one origin. Express and Socket.IO share one HTTP server. Only Node.js accesses PostgreSQL. Database changes are versioned through ordered SQL migrations recorded in `schema_migrations`.
