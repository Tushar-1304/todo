# Changelog

## 0.4.0 - 2026-09-23
- Added responsive identity-selection and private-code interface
- Added automatic session restoration and redirects
- Added show/hide access-code control and accessible form states
- Added same-origin frontend API wrapper with network-error handling
- Added loading, rate-limit, error, and success feedback
- Added mobile safe-area and reduced-motion support
- Added project-wide JavaScript syntax checker
- Corrected authentication middleware error propagation
- Added frontend consistency tests

## 0.3.0 - 2026-09-23
- Added Argon2id access verification, opaque sessions, HTTP-only cookies, logout, validation, and rate limiting

## 0.2.0 - 2026-09-23
- Added checksum migrations, core PostgreSQL schema, indexes, seeds, and reset tooling

## 0.1.0 - 2026-09-23
- Added application foundation, Express, Socket.IO, security headers, and tracking docs
