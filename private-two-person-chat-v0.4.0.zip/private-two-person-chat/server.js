import { createServer } from "node:http";
import { Server } from "socket.io";
import { createApp } from "./src/app.js";
import { env } from "./src/config/env.js";
import { closeDatabasePool } from "./src/config/database.js";
import { logger } from "./src/utils/logger.js";

const app = createApp();
const httpServer = createServer(app);
const io = new Server(httpServer, { serveClient: true, transports: ["websocket", "polling"], cors: false });

io.on("connection", (socket) => {
  socket.emit("system:ready", { message: "Real-time server is available.", version: "0.2.0" });
});

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info("shutdown_started", { signal });
  const timer = setTimeout(() => process.exit(1), 10000);
  timer.unref();
  io.close();
  httpServer.close(async () => {
    await closeDatabasePool();
    clearTimeout(timer);
    logger.info("shutdown_complete");
    process.exit(0);
  });
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
httpServer.listen(env.PORT, "0.0.0.0", () => logger.info("server_started", { port: env.PORT, environment: env.NODE_ENV, appUrl: env.APP_URL }));
