import { env } from "../config/env.js";
import { revokeRawToken } from "../services/session.service.js";
import { clearSessionCookie } from "../utils/cookies.js";
export async function getSession(req,res){return res.json({success:true,data:req.auth});}
export async function logout(req,res){const token=req.cookies?.[env.SESSION_COOKIE_NAME];await revokeRawToken(token);clearSessionCookie(res);return res.status(204).send();}
