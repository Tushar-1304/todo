import { env } from "../config/env.js";
import { verifyAccessAndCreateSession } from "../services/access.service.js";
import { sessionCookieOptions } from "../utils/cookies.js";
export async function verifyAccess(req,res){
  const result=await verifyAccessAndCreateSession({...req.validatedBody,userAgent:req.get("user-agent")});
  if(!result)return res.status(401).json({success:false,error:{code:"INVALID_ACCESS",message:"The selected identity or private access code is incorrect."}});
  res.cookie(env.SESSION_COOKIE_NAME,result.rawToken,sessionCookieOptions());
  return res.status(201).json({success:true,data:{participant:{id:result.participant.id,identityKey:result.participant.identity_key,displayName:result.participant.display_name},expiresAt:result.expiresAt}});
}
