import { Router } from "express";
import { verifyAccess } from "../controllers/access.controller.js";
import { accessRateLimiter } from "../middleware/rate-limiters.js";
import { validateBody } from "../middleware/validate.js";
import { asyncHandler } from "../utils/async-handler.js";
import { verifyAccessSchema } from "../validators/access.validators.js";
export const accessRouter=Router();
accessRouter.post("/verify",accessRateLimiter,validateBody(verifyAccessSchema),asyncHandler(verifyAccess));
