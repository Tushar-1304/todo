import { Router } from "express";
import { getSession,logout } from "../controllers/session.controller.js";
import { authenticate } from "../middleware/authenticate.js";
import { sessionRateLimiter } from "../middleware/rate-limiters.js";
import { asyncHandler } from "../utils/async-handler.js";
export const sessionRouter=Router();
sessionRouter.use(sessionRateLimiter);
sessionRouter.get("/",asyncHandler(authenticate),getSession);
sessionRouter.post("/logout",asyncHandler(authenticate),asyncHandler(logout));
