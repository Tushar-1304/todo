import { getDatabasePool, requireDatabaseUrl } from "../config/database.js";
export async function findParticipantByIdentityKey(identityKey,client=getDatabasePool()){
  if(!client) requireDatabaseUrl();
  const {rows}=await client.query("SELECT id, identity_key, display_name FROM participants WHERE identity_key=$1",[identityKey]);
  return rows[0]||null;
}
export async function findOtherParticipant(participantId,client=getDatabasePool()){
  if(!client) requireDatabaseUrl();
  const {rows}=await client.query("SELECT id, identity_key, display_name FROM participants WHERE id<>$1 ORDER BY identity_key LIMIT 1",[participantId]);
  return rows[0]||null;
}
