import { getDatabasePool, requireDatabaseUrl } from "../config/database.js";
function db(client){const value=client||getDatabasePool();if(!value)requireDatabaseUrl();return value;}
export async function createSession({participantId,tokenHash,userAgent,expiresAt},client){
  const {rows}=await db(client).query(`INSERT INTO sessions(participant_id,token_hash,user_agent,expires_at) VALUES($1,$2,$3,$4)
  RETURNING id,participant_id,created_at,last_used_at,expires_at`,[participantId,tokenHash,userAgent?.slice(0,500)||null,expiresAt]);return rows[0];
}
export async function findActiveSessionByHash(tokenHash){
  const {rows}=await db().query(`SELECT s.id,s.participant_id,s.created_at,s.last_used_at,s.expires_at,p.identity_key,p.display_name
  FROM sessions s JOIN participants p ON p.id=s.participant_id WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>NOW()`,[tokenHash]);return rows[0]||null;
}
export async function touchSession(id){await db().query("UPDATE sessions SET last_used_at=NOW() WHERE id=$1 AND last_used_at<NOW()-INTERVAL '15 minutes'",[id]);}
export async function revokeSessionByHash(tokenHash){const r=await db().query("UPDATE sessions SET revoked_at=COALESCE(revoked_at,NOW()) WHERE token_hash=$1 RETURNING id",[tokenHash]);return r.rowCount>0;}
export async function revokeAllSessions(){const r=await db().query("UPDATE sessions SET revoked_at=COALESCE(revoked_at,NOW()) WHERE revoked_at IS NULL RETURNING id");return r.rowCount;}
