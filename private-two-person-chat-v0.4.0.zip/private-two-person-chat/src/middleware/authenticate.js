import { env } from "../config/env.js";
import { authenticateRawToken } from "../services/session.service.js";
import { clearSessionCookie } from "../utils/cookies.js";

export async function authenticate(req, res, next) {
  try {
    const auth = await authenticateRawToken(req.cookies?.[env.SESSION_COOKIE_NAME]);
    if (!auth) {
      clearSessionCookie(res);
      return res.status(401).json({
        success: false,
        error: { code: "UNAUTHENTICATED", message: "A valid private session is required." }
      });
    }
    req.auth = auth;
    return next();
  } catch (error) {
    return next(error);
  }
}
