import { findActiveSessionByHash, revokeSessionByHash, touchSession } from "../repositories/session.repository.js";
import { findOtherParticipant } from "../repositories/participant.repository.js";
import { hashSessionToken } from "../utils/crypto.js";
export async function authenticateRawToken(rawToken){
  if(!rawToken)return null;let hash;try{hash=hashSessionToken(rawToken);}catch{return null;}
  const session=await findActiveSessionByHash(hash);if(!session)return null;
  touchSession(session.id).catch(()=>{});
  const other=await findOtherParticipant(session.participant_id);
  return {session:{id:session.id,expiresAt:session.expires_at},participant:{id:session.participant_id,identityKey:session.identity_key,displayName:session.display_name},otherParticipant:other?{id:other.id,identityKey:other.identity_key,displayName:other.display_name}:null};
}
export async function revokeRawToken(rawToken){if(!rawToken)return false;return revokeSessionByHash(hashSessionToken(rawToken));}
