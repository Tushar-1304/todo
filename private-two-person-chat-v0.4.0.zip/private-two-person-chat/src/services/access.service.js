import argon2 from "argon2";
import { env, requireAuthenticationEnvironment } from "../config/env.js";
import { findParticipantByIdentityKey } from "../repositories/participant.repository.js";
import { createSession } from "../repositories/session.repository.js";
import { createSessionToken, hashSessionToken } from "../utils/crypto.js";
const hashes={tushar:()=>env.TUSHAR_ACCESS_CODE_HASH,friend:()=>env.FRIEND_ACCESS_CODE_HASH};
export async function verifyAccessAndCreateSession({identity,accessCode,userAgent}){
  requireAuthenticationEnvironment();
  const valid=await argon2.verify(hashes[identity](),accessCode,{type:argon2.argon2id});
  if(!valid) return null;
  const participant=await findParticipantByIdentityKey(identity);
  if(!participant) throw Object.assign(new Error("Configured participant does not exist. Run database seeds."),{code:"PARTICIPANT_NOT_FOUND"});
  const rawToken=createSessionToken();const tokenHash=hashSessionToken(rawToken);const expiresAt=new Date(Date.now()+env.SESSION_DURATION_DAYS*86400000);
  await createSession({participantId:participant.id,tokenHash,userAgent,expiresAt});
  return {rawToken,participant,expiresAt};
}
