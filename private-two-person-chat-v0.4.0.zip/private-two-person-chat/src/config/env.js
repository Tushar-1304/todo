import "dotenv/config";
import { z } from "zod";
const bool = z.preprocess((v) => typeof v === "string" ? v.trim().toLowerCase() === "true" : v, z.boolean());
const optionalUrl = z.preprocess((v) => typeof v === "string" && v.trim() === "" ? undefined : v, z.string().url().optional());
const optionalString = z.preprocess((v) => typeof v === "string" && v.trim() === "" ? undefined : v, z.string().optional());
const schema = z.object({
  NODE_ENV: z.enum(["development","test","production"]).default("development"), PORT: z.coerce.number().int().min(1).max(65535).default(3000),
  APP_NAME: z.string().trim().min(1).default("Private Two-Person Chat"), APP_URL: z.string().url().default("http://localhost:3000"),
  DATABASE_URL: optionalUrl, DATABASE_SSL: bool.default(false), DATABASE_POOL_MAX: z.coerce.number().int().min(1).max(20).default(5),
  DATABASE_CONNECTION_TIMEOUT_MS: z.coerce.number().int().min(1000).default(10000), DATABASE_IDLE_TIMEOUT_MS: z.coerce.number().int().min(1000).default(30000), DATABASE_QUERY_TIMEOUT_MS: z.coerce.number().int().min(1000).default(10000),
  SESSION_COOKIE_NAME: z.string().regex(/^[A-Za-z0-9_-]+$/).default("private_chat_session"), SESSION_DURATION_DAYS: z.coerce.number().int().min(1).max(365).default(30),
  SESSION_TOKEN_PEPPER: optionalString, TUSHAR_ACCESS_CODE_HASH: optionalString, FRIEND_ACCESS_CODE_HASH: optionalString,
  ACCESS_RATE_LIMIT_WINDOW_MS: z.coerce.number().int().min(1000).default(900000), ACCESS_RATE_LIMIT_MAX: z.coerce.number().int().min(1).default(5),
  SESSION_RATE_LIMIT_WINDOW_MS: z.coerce.number().int().min(1000).default(60000), SESSION_RATE_LIMIT_MAX: z.coerce.number().int().min(1).default(60),
  LOG_LEVEL: z.enum(["debug","info","warn","error"]).default("info")
});
const parsed=schema.safeParse(process.env);
if(!parsed.success){console.error("Environment configuration is invalid:\n"+parsed.error.issues.map(i=>`${i.path.join(".")}: ${i.message}`).join("\n"));process.exit(1);}
export const env=Object.freeze(parsed.data);
export function requireAuthenticationEnvironment(){
  const missing=[];
  if(!env.DATABASE_URL) missing.push("DATABASE_URL");
  if(!env.SESSION_TOKEN_PEPPER || env.SESSION_TOKEN_PEPPER.length<32) missing.push("SESSION_TOKEN_PEPPER (minimum 32 characters)");
  if(!env.TUSHAR_ACCESS_CODE_HASH) missing.push("TUSHAR_ACCESS_CODE_HASH");
  if(!env.FRIEND_ACCESS_CODE_HASH) missing.push("FRIEND_ACCESS_CODE_HASH");
  if(missing.length) throw Object.assign(new Error(`Authentication configuration missing: ${missing.join(", ")}`),{code:"AUTH_CONFIGURATION_MISSING"});
}
