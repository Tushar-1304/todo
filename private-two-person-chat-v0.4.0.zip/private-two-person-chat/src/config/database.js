import pg from "pg";
import { env } from "./env.js";
import { logger } from "../utils/logger.js";
const { Pool } = pg;
let pool;

export function requireDatabaseUrl() {
  if (!env.DATABASE_URL) throw Object.assign(new Error("DATABASE_URL is required for this operation."), { code: "DATABASE_NOT_CONFIGURED" });
  return env.DATABASE_URL;
}
export function getDatabasePool() {
  if (!env.DATABASE_URL) return null;
  if (!pool) {
    pool = new Pool({
      connectionString: env.DATABASE_URL,
      max: env.DATABASE_POOL_MAX,
      connectionTimeoutMillis: env.DATABASE_CONNECTION_TIMEOUT_MS,
      idleTimeoutMillis: env.DATABASE_IDLE_TIMEOUT_MS,
      query_timeout: env.DATABASE_QUERY_TIMEOUT_MS,
      statement_timeout: env.DATABASE_QUERY_TIMEOUT_MS,
      ssl: env.DATABASE_SSL ? { rejectUnauthorized: false } : false
    });
    pool.on("error", (error) => logger.error("database_pool_error", { message: error.message }));
  }
  return pool;
}
export async function withTransaction(work) {
  const databasePool = getDatabasePool();
  if (!databasePool) requireDatabaseUrl();
  const client = await databasePool.connect();
  try {
    await client.query("BEGIN");
    const result = await work(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
export async function checkDatabaseConnection() {
  const databasePool = getDatabasePool();
  if (!databasePool) return { configured: false, reachable: false };
  try { await databasePool.query("SELECT 1"); return { configured: true, reachable: true }; }
  catch (error) { logger.warn("database_health_check_failed", { message: error.message }); return { configured: true, reachable: false }; }
}
export async function closeDatabasePool() { if (pool) { await pool.end(); pool = undefined; } }
