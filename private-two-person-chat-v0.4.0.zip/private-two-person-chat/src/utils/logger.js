import { env } from "../config/env.js";
const levels = { debug: 10, info: 20, warn: 30, error: 40 };
function write(level, event, details = {}) {
  if (levels[level] < levels[env.LOG_LEVEL]) return;
  const line = JSON.stringify({ timestamp: new Date().toISOString(), level, event, ...details });
  if (level === "error") console.error(line); else if (level === "warn") console.warn(line); else console.log(line);
}
export const logger = { debug: (e,d) => write("debug",e,d), info: (e,d) => write("info",e,d), warn: (e,d) => write("warn",e,d), error: (e,d) => write("error",e,d) };
