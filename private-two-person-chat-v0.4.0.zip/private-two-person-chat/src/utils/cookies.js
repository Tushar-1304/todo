import { env } from "../config/env.js";
export function sessionCookieOptions(){return {httpOnly:true,secure:env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:env.SESSION_DURATION_DAYS*86400000};}
export function clearSessionCookie(res){res.clearCookie(env.SESSION_COOKIE_NAME,{httpOnly:true,secure:env.NODE_ENV==="production",sameSite:"lax",path:"/"});}
