import crypto from "node:crypto";
import { env } from "../config/env.js";
export function createSessionToken(){return crypto.randomBytes(48).toString("base64url");}
export function hashSessionToken(token){
  if(!env.SESSION_TOKEN_PEPPER) throw new Error("SESSION_TOKEN_PEPPER is not configured.");
  return crypto.createHmac("sha256",env.SESSION_TOKEN_PEPPER).update(token).digest("hex");
}
export function safeEqualText(a,b){const x=Buffer.from(String(a));const y=Buffer.from(String(b));return x.length===y.length&&crypto.timingSafeEqual(x,y);}
