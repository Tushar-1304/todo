import { z } from "zod";
export const verifyAccessSchema=z.object({identity:z.enum(["tushar","friend"]),accessCode:z.string().min(1).max(256)}).strict();
