import test from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import { createApp } from "../src/app.js";

test("GET /health returns a safe health response", async () => {
  const response = await request(createApp()).get("/health");
  assert.equal(response.status, 200);
  assert.equal(response.body.status, "ok");
  assert.equal(response.body.version, "0.1.0");
  assert.ok(response.body.serverTime);
  assert.deepEqual(response.body.database, { configured: false, reachable: false });
});

test("unknown API route returns structured JSON", async () => {
  const response = await request(createApp()).get("/api/unknown");
  assert.equal(response.status, 404);
  assert.equal(response.body.error.code, "NOT_FOUND");
});
