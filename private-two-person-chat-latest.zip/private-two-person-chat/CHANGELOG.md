# Changelog

## 0.1.0 - 2026-09-23

- Added project requirements and tracking documents
- Added Express application and shared HTTP server
- Added Socket.IO foundation
- Added static frontend pages
- Added Helmet security headers
- Added validated environment configuration
- Added optional PostgreSQL connection pool
- Added health endpoint and structured errors
- Added graceful shutdown
- Added foundation tests
