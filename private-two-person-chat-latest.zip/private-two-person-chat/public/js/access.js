// Stage 1 deliberately contains no identity or authentication logic.
// The secure access flow is introduced after the database and session layers.
