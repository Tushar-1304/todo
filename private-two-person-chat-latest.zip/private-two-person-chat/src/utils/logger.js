import { env } from "../config/env.js";

const levels = { debug: 10, info: 20, warn: 30, error: 40 };

function write(level, event, details = {}) {
  if (levels[level] < levels[env.LOG_LEVEL]) return;

  const entry = {
    timestamp: new Date().toISOString(),
    level,
    event,
    ...details
  };

  const line = JSON.stringify(entry);
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export const logger = {
  debug: (event, details) => write("debug", event, details),
  info: (event, details) => write("info", event, details),
  warn: (event, details) => write("warn", event, details),
  error: (event, details) => write("error", event, details)
};
