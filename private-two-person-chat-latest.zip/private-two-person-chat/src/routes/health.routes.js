import { Router } from "express";
import { checkDatabaseConnection } from "../config/database.js";

export const healthRouter = Router();

healthRouter.get("/", async (req, res) => {
  const database = await checkDatabaseConnection();
  const healthy = !database.configured || database.reachable;

  return res.status(healthy ? 200 : 503).json({
    status: healthy ? "ok" : "degraded",
    version: "0.1.0",
    serverTime: new Date().toISOString(),
    database
  });
});
