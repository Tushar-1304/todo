export function notFound(req, res) {
  if (req.path.startsWith("/api/")) {
    return res.status(404).json({ success: false, error: { code: "NOT_FOUND", message: "API route not found." } });
  }
  return res.status(404).send("Page not found.");
}
