import { env } from "../config/env.js";
import { logger } from "../utils/logger.js";

export function errorHandler(error, req, res, next) {
  if (res.headersSent) return next(error);

  logger.error("request_failed", {
    method: req.method,
    path: req.originalUrl,
    message: error.message
  });

  const message = env.NODE_ENV === "production" ? "An unexpected error occurred." : error.message;
  return res.status(error.statusCode || 500).json({
    success: false,
    error: { code: error.code || "INTERNAL_ERROR", message }
  });
}
