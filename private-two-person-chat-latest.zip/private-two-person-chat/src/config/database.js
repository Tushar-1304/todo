import pg from "pg";
import { env } from "./env.js";
import { logger } from "../utils/logger.js";

const { Pool } = pg;
let pool;

export function getDatabasePool() {
  if (!env.DATABASE_URL) return null;

  if (!pool) {
    pool = new Pool({
      connectionString: env.DATABASE_URL,
      max: env.DATABASE_POOL_MAX,
      connectionTimeoutMillis: env.DATABASE_CONNECTION_TIMEOUT_MS,
      idleTimeoutMillis: env.DATABASE_IDLE_TIMEOUT_MS,
      ssl: env.DATABASE_SSL ? { rejectUnauthorized: false } : false
    });

    pool.on("error", (error) => {
      logger.error("database_pool_error", { message: error.message });
    });
  }

  return pool;
}

export async function checkDatabaseConnection() {
  const databasePool = getDatabasePool();
  if (!databasePool) return { configured: false, reachable: false };

  try {
    await databasePool.query("SELECT 1");
    return { configured: true, reachable: true };
  } catch (error) {
    logger.warn("database_health_check_failed", { message: error.message });
    return { configured: true, reachable: false };
  }
}

export async function closeDatabasePool() {
  if (pool) {
    await pool.end();
    pool = undefined;
  }
}
