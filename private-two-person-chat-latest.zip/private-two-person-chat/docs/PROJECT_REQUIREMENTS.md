# Project Requirements

## Purpose

Create a secure, private, real-time, text-only chat application for exactly two predefined participants: `tushar` and `friend`.

## MVP Features

- First-time identity selection and private access-code verification
- Secure opaque sessions stored as hashed tokens
- One permanent conversation
- Real-time text messaging with Socket.IO
- PostgreSQL message history
- Reply support
- Sent, delivered, read, and failed states
- Online and offline presence across multiple tabs and devices
- Automatic reconnection and missed-message synchronization
- Mobile and desktop layouts
- One public URL serving the frontend, API, and Socket.IO

## Excluded from MVP

Public signup, email OTP, user search, contact requests, contact lists, groups, media, calls, reactions, message editing, message deletion, push notifications, and end-to-end encryption.
