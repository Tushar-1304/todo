# Architecture Decisions

## ADR-001: Single-origin application

The Express service serves pages, static assets, REST APIs, and Socket.IO from one public URL.

## ADR-002: PostgreSQL persistence

PostgreSQL stores participants, sessions, messages, and read markers. Local files and server memory are not used for persistent data.

## ADR-003: Opaque sessions

The final authentication flow will use random opaque session tokens in HTTP-only cookies. Only token hashes will be stored in PostgreSQL.

## ADR-004: Vanilla frontend

The browser client uses semantic HTML, CSS, and vanilla JavaScript to minimize bundle size and maintenance overhead.
