# Architecture

```text
Browser
  |-- GET / and /chat
  |-- REST /api/*
  `-- Socket.IO /socket.io/*
          |
Node.js HTTP server
  |-- Express
  |-- Socket.IO
  |-- security and validation
  `-- pg.Pool
          |
PostgreSQL
```

The frontend and backend use the same origin. PostgreSQL is never exposed to the browser. Express and Socket.IO share one HTTP server.
