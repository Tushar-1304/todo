# Stage 1 Manual Test Checklist

- [ ] `npm install` completes
- [ ] Copy `.env.example` to `.env`
- [ ] `npm test` passes
- [ ] `npm run dev` starts the server
- [ ] `http://localhost:3000` displays the foundation page
- [ ] `http://localhost:3000/health` returns JSON with `status: ok`
- [ ] `http://localhost:3000/chat` displays the placeholder chat page
- [ ] Browser developer tools show no frontend error
- [ ] Stopping the server performs a graceful shutdown
