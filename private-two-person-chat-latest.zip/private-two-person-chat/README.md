# Private Two-Person Chat

Version 0.1.0 establishes the secure application foundation for a private real-time chat used by exactly two predefined participants.

## Requirements

- Node.js 20, 22, or 24
- npm
- PostgreSQL will be required beginning with Stage 2

## Local Setup

```bash
npm install
```

Copy the environment template.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Linux or macOS:

```bash
cp .env.example .env
```

Start development mode:

```bash
npm run dev
```

Open:

```text
http://localhost:3000
http://localhost:3000/health
http://localhost:3000/chat
```

## Tests

```bash
npm test
npm run check
```

## Current Scope

Stage 1 includes the project structure, Express, Socket.IO foundation, security headers, environment validation, PostgreSQL pool configuration, static pages, health endpoint, structured errors, and graceful shutdown.

Authentication is intentionally not implemented yet. It depends on the Stage 2 sessions table and will be built in Stage 3.

## Deployment Shape

Deploy this repository as one long-running Node.js web service.

Build command:

```text
npm ci
```

Start command:

```text
npm start
```

Health-check path:

```text
/health
```

The server uses `process.env.PORT` and binds to `0.0.0.0`.

## Security Notes

- Never commit `.env`.
- Do not put readable access codes in the source code.
- Do not expose `DATABASE_URL` to browser JavaScript.
- Production credentials belong in the hosting provider's environment settings.
