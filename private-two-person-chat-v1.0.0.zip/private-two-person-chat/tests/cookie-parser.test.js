import test from "node:test";
import assert from "node:assert/strict";
import { parseCookieHeader } from "../src/sockets/cookie-parser.js";

test("socket cookie parser decodes multiple cookies", () => {
  assert.deepEqual(parseCookieHeader("a=one; private_chat_session=hello%20world"), { a: "one", private_chat_session: "hello world" });
});
