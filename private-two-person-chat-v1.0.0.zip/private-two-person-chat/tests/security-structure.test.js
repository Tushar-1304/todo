import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";

test("private pages and APIs use no-store middleware", async () => {
  const app = await fs.readFile("src/app.js", "utf8");
  assert.match(app, /app\.get\("\/", noStore/);
  assert.match(app, /app\.get\("\/chat", noStore/);
  assert.match(app, /app\.use\("\/api\/messages", noStore/);
});

test("Docker runtime is non-root and production ready", async () => {
  const dockerfile = await fs.readFile("Dockerfile", "utf8");
  assert.match(dockerfile, /USER app/);
  assert.match(dockerfile, /npm ci --omit=dev/);
});

test("repository never contains obvious readable access-code assignments", async () => {
  const env = await fs.readFile(".env.example", "utf8");
  assert.match(env, /TUSHAR_ACCESS_CODE_HASH=\n/);
  assert.match(env, /FRIEND_ACCESS_CODE_HASH=\n/);
});
