# Ubuntu VM Deployment

## Install and run

Install Node.js 22 LTS, Nginx, Git, and Certbot. Clone the private repository and run:

```bash
npm ci
npm run db:migrate
npm run db:seed
npm run verify
sudo npm install -g pm2
pm2 start server.js --name private-chat
pm2 save
pm2 startup
```

Copy `deploy/nginx/private-chat.conf` to `/etc/nginx/sites-available/private-chat`, replace `chat.example.com`, enable the site, and test configuration:

```bash
sudo ln -s /etc/nginx/sites-available/private-chat /etc/nginx/sites-enabled/private-chat
sudo nginx -t
sudo systemctl reload nginx
```

Issue HTTPS after DNS points to the VM:

```bash
sudo certbot --nginx -d chat.example.com
```

Allow only SSH, HTTP, and HTTPS through the firewall:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

Do not expose port 3000 publicly. Nginx proxies normal HTTP and Socket.IO upgrade requests to `127.0.0.1:3000`.
