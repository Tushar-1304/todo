# Northflank Deployment

1. Create a project and a combined service connected to the private Git repository.
2. Use the included Dockerfile, or select a Node build with `npm ci` and `npm start`.
3. Expose the service's HTTP port by using the platform-provided `PORT` variable.
4. Configure `/health` as the health check.
5. Add production environment variables through Northflank secrets. Never upload `.env`.
6. Run `npm run db:migrate && npm run db:seed` as a one-time job before the first release and after any future migration.
7. Keep one service instance. Presence is intentionally held in memory and is not yet distributed through Redis.
8. Verify the assigned HTTPS domain can upgrade `/socket.io/` connections.
