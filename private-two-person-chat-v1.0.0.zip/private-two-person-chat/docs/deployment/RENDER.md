# Render Deployment

1. Push the project to a private Git repository.
2. Create a Render **Web Service**, not a Static Site.
3. Use `npm ci` as the build command and `npm start` as the start command.
4. Set `/health` as the health-check path.
5. Add every secret from `.env.example` in the Render environment settings.
6. Set `NODE_ENV=production`, `DATABASE_SSL=true`, and `APP_URL` to the final HTTPS origin.
7. Run migrations and seeds before the first start. The included `render.yaml` declares this as a pre-deploy command.
8. Confirm the browser uses `wss://` automatically through the HTTPS origin.

Render free web services can sleep after inactivity, so the first connection after an idle period can be delayed. The frontend reconnect state and database synchronization are designed for this behavior.
