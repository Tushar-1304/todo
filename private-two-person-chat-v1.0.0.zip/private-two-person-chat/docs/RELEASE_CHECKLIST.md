# Version 1.0.0 Release Checklist

- [ ] `npm ci` completes using the committed package lock
- [ ] `npm run verify` passes
- [ ] Production environment variables are configured
- [ ] Access-code hashes were generated locally
- [ ] Migration status is fully applied
- [ ] Exactly two participants exist
- [ ] `/health` returns `status: ok`
- [ ] Both identities can authenticate in separate browsers
- [ ] Live messaging works in both directions
- [ ] Sent, delivered, and read states work
- [ ] Reply, pagination, reconnection, and logout work
- [ ] HTTPS and WSS work on the final domain
- [ ] Backup and recovery procedure is documented and tested
- [ ] `.env` is absent from Git history
