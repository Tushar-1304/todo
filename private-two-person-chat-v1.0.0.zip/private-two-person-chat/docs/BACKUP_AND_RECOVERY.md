# Backup and Recovery

The database is the source of truth. The application filesystem is disposable.

- Use the database provider's backup or export capability.
- For a manual PostgreSQL export, use `pg_dump` from a trusted machine.
- Test restoration into a separate database before relying on a backup.
- Keep access-code hashes, the session pepper, and database credentials in a password manager, separate from database exports.
- After restoring a database to a new host, update `DATABASE_URL`, run `npm run db:status`, and start the service.
- Do not rerun old migrations manually. The `schema_migrations` checksums protect migration history.
