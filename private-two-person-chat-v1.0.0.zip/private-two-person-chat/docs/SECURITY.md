# Security Model

- Exactly two immutable database identities are allowed.
- Access codes are verified with Argon2id hashes supplied through environment variables.
- Readable access codes are never stored in source code or PostgreSQL.
- Browser sessions use random opaque tokens in HTTP-only, SameSite cookies.
- PostgreSQL stores only keyed HMAC-SHA-256 token hashes.
- Session expiry and revocation are enforced on HTTP and new Socket.IO handshakes.
- Message sender identity always comes from the authenticated server session.
- Message and reply text are rendered with `textContent`.
- Parameterized SQL is used throughout the repositories.
- Access and message operations have separate rate limits.
- Authentication pages, chat pages, and private APIs use `Cache-Control: no-store`.
- Production requires HTTPS through `APP_URL` preflight validation.
- Server logs exclude access codes, session tokens, and message contents.

## Operational Response

If an access code may have leaked:

1. Generate a replacement Argon2id hash with `npm run access:hash`.
2. Replace the matching environment variable.
3. Run `npm run sessions:revoke` to invalidate every browser.
4. Redeploy or restart the service.

Rotate `SESSION_TOKEN_PEPPER` only when intentionally invalidating all sessions. Existing database session hashes become unusable after rotation.
