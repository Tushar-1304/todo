# Troubleshooting

## Health says database is degraded

Check `DATABASE_URL`, `DATABASE_SSL`, network access, database availability, and whether the database password contains URL characters that require encoding.

## Access verification always fails

Confirm the correct hash is assigned to the correct identity and that the entered access code matches exactly. Regenerate hashes if uncertain.

## Browser returns to the access page

The session is missing, expired, revoked, or signed with a different `SESSION_TOKEN_PEPPER`. Check cookies and server logs without copying token values.

## Messages save but do not appear live

Check the Socket.IO connection in browser developer tools, HTTPS/WSS proxy configuration, and whether both browsers are authenticated against the same server instance and database.

## Messages appear after refresh but status remains Sent

The recipient did not send a delivery acknowledgement, commonly because its socket was offline or the page was closed. Reopening the page loads the message and acknowledges delivery.

## Presence is wrong after scaling

Version 1.0.0 supports one Node.js instance. Multiple instances need a Socket.IO Redis adapter and a shared presence store.
