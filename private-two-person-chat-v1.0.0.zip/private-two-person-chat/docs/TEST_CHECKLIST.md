# Final Acceptance Test

1. Run `npm install` once and commit the generated `package-lock.json`.
2. Run `npm run db:setup` against a development PostgreSQL database.
3. Run `npm run verify`.
4. Start with `npm run dev`.
5. Authenticate Tushar in a normal browser and Friend in an incognito browser.
6. Test messages, replies, delivery/read status, pagination, disconnect/reconnect, multiple tabs, refresh persistence, and logout.
7. Run `npm run sessions:revoke` and verify both browsers are rejected on their next session validation.
8. Deploy to the selected host and repeat the two-browser test over HTTPS/WSS.
