# Private Two-Person Chat

A secure, single-origin, text-only real-time chat for exactly two predefined participants. Version 1.0.0 includes the complete frontend, Express APIs, authenticated Socket.IO server, PostgreSQL persistence, opaque sessions, replies, message states, presence, recovery synchronization, tests, and deployment documentation.

## Stack

- HTML, CSS, and vanilla JavaScript
- Node.js and Express
- Socket.IO
- PostgreSQL through `pg.Pool`
- Argon2id access-code verification
- HTTP-only opaque session cookies

## Local Setup

```bash
npm install
```

Copy `.env.example` to `.env`. Configure PostgreSQL, add a random 32+ character `SESSION_TOKEN_PEPPER`, and generate separate hashes:

```bash
npm run access:hash
npm run access:hash
npm run db:setup
npm run verify
npm run dev
```

Open `http://localhost:3000` in a normal browser for one participant and an incognito browser for the other.

## Main Commands

```bash
npm run dev
npm start
npm run verify
npm run db:migrate
npm run db:status
npm run db:seed
npm run access:hash
npm run sessions:revoke
```

`npm start` runs a production preflight check before starting. Production requires complete authentication variables and an HTTPS `APP_URL`.

## Architecture

The Node.js service serves `/`, `/chat`, `/api/*`, and `/socket.io/*` from one origin. PostgreSQL stores participants, opaque-session hashes, messages, replies, delivery timestamps, and read markers. The browser never receives database credentials or access-code hashes.

## Deployment

- `docs/deployment/RENDER.md`
- `docs/deployment/NORTHFLANK.md`
- `docs/deployment/UBUNTU_VM.md`
- `Dockerfile`
- `render.yaml`
- `deploy/nginx/private-chat.conf`

## Operations

- Security model: `docs/SECURITY.md`
- Backup and recovery: `docs/BACKUP_AND_RECOVERY.md`
- Troubleshooting: `docs/TROUBLESHOOTING.md`
- Final acceptance: `docs/RELEASE_CHECKLIST.md`

## Important Scope

This release is intended for exactly two trusted participants and one Node.js instance. It does not include public accounts, media, groups, push notifications, end-to-end encryption, or multi-instance Redis presence.
