# Changelog

## 1.0.0 - 2026-09-23
- Completed security and consistency hardening
- Added private-response cache prevention and production preflight checks
- Added non-root Docker deployment and Render blueprint
- Added Northflank and Ubuntu/Nginx/PM2 deployment guides
- Added GitHub Actions verification workflow
- Added security, backup, troubleshooting, and release documentation
- Added final security structure and cookie parser tests

## 0.7.0 - 2026-09-23
- Added complete responsive private chat interface
## 0.6.0 - 2026-09-23
- Added authenticated Socket.IO communication and presence
## 0.5.0 - 2026-09-23
- Added message persistence, replies, read markers, and recovery
## 0.4.0 - 2026-09-23
- Added identity frontend
## 0.3.0 - 2026-09-23
- Added secure access-code authentication and opaque sessions
## 0.2.0 - 2026-09-23
- Added PostgreSQL schema and migrations
## 0.1.0 - 2026-09-23
- Added application foundation
