import { env, requireAuthenticationEnvironment } from "../src/config/env.js";

try {
  requireAuthenticationEnvironment();
  if (env.NODE_ENV === "production" && !env.APP_URL.startsWith("https://")) {
    throw new Error("APP_URL must use HTTPS in production.");
  }
  console.log("Preflight configuration check passed.");
} catch (error) {
  console.error(`Preflight failed: ${error.message}`);
  process.exit(1);
}
